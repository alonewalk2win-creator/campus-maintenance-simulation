"""Campus Facility Maintenance Request Management System - Flask + SQLite application.

Every screen reads from / writes to the relational database designed in db/01_schema.sql.
All SQL uses parameterised queries; database rule violations (CHECK, FOREIGN KEY, UNIQUE and
trigger RAISE) are caught and shown as friendly messages.
"""
import os
import re
import sqlite3
from datetime import datetime

from flask import Flask, g, render_template, request, redirect, url_for, flash, abort

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("CAMPUS_DB", os.path.join(BASE, "..", "db", "campus_fms.db"))

app = Flask(__name__)
app.secret_key = "campus-fms-demo"


# --------------------------------------------------------------------------- database
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, isolation_level=None)   # explicit BEGIN / COMMIT below
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    con = g.pop("db", None)
    if con is not None:
        con.close()


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def q(sql, args=(), one=False):
    cur = db().execute(sql, args)
    rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows


ERROR_MAP = [
    ("Invalid status transition", "This status change is not allowed by the workflow."),
    ("Technician has reached maximum active jobs", "Assignment refused: technician already has the maximum number of active jobs."),
    ("Technician is inactive", "Assignment refused: technician is inactive."),
    ("Request is not open for assignment", "Assignment refused: only Open requests can be assigned."),
    ("Insufficient material stock", "Material issue refused: quantity exceeds the available stock."),
    ("Materials can be issued only", "Materials can be issued only while the request is Assigned, In Progress or On Hold."),
    ("Feedback is allowed only", "Feedback can be submitted only after the request is Closed."),
    ("Only Open or Cancelled requests", "Delete refused: only Open or Cancelled requests can be deleted (use Cancel instead)."),
    ("Work can be logged only", "Work can be logged only against an active assignment."),
    ("CHECK constraint failed: status <> 'Closed'", "Closure details (remarks and closing time) are mandatory to close a request."),
    ("UNIQUE constraint failed: feedback.request_id", "Feedback has already been submitted for this request."),
    ("UNIQUE constraint failed: maintenance_request.request_no", "Request number already exists."),
    ("UNIQUE constraint failed", "A record with the same unique value already exists."),
    ("FOREIGN KEY constraint failed", "Operation refused: the record is referenced by other records (or the reference does not exist)."),
    ("CHECK constraint failed", "A value violates a database rule (check constraint)."),
    ("uq_one_active_assignment", "This request already has an active technician."),
]


def friendly(exc):
    msg = str(exc)
    for key, text in ERROR_MAP:
        if key in msg:
            return text
    return "Database error: " + msg


def run_tx(fn, ok_msg):
    """Run fn() inside one transaction; roll back everything on any database error."""
    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        result = fn()
        con.execute("COMMIT")
        flash(ok_msg, "ok")
        return result
    except (sqlite3.IntegrityError, sqlite3.OperationalError) as exc:
        con.execute("ROLLBACK")
        flash(friendly(exc), "err")
    except ValueError as exc:
        con.execute("ROLLBACK")
        flash(str(exc), "err")
    return None


# --------------------------------------------------------------------------- validation helpers
def req_text(name, min_len=1, label=None):
    v = (request.form.get(name) or "").strip()
    if len(v) < min_len:
        raise ValueError(f"{label or name} is required (minimum {min_len} characters).")
    return v


def req_int(name, label=None, lo=None, hi=None):
    try:
        v = int(request.form.get(name, ""))
    except ValueError:
        raise ValueError(f"{label or name} must be a whole number.")
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise ValueError(f"{label or name} must be between {lo} and {hi}.")
    return v


def req_num(name, label=None, lo=None, hi=None):
    try:
        v = float(request.form.get(name, ""))
    except ValueError:
        raise ValueError(f"{label or name} must be a number.")
    if lo is not None and v < lo:
        raise ValueError(f"{label or name} cannot be less than {lo}.")
    if hi is not None and v > hi:
        raise ValueError(f"{label or name} cannot be more than {hi}.")
    return v


# --------------------------------------------------------------------------- dashboard
@app.route("/")
def dashboard():
    status_counts = {r["status"]: r["n"] for r in q("SELECT status, COUNT(*) n FROM maintenance_request GROUP BY status")}
    totals = q("""SELECT COUNT(*) total,
                         SUM(status NOT IN ('Closed','Cancelled')) pending,
                         (SELECT ROUND(AVG(response_hours),1) FROM v_response_time) avg_resp,
                         (SELECT ROUND(AVG(rating),2) FROM feedback) avg_rating,
                         (SELECT COUNT(*) FROM v_response_time WHERE sla_status='SLA Breached') breaches
                  FROM maintenance_request""", one=True)
    cost = q("SELECT ROUND(SUM(labour_cost+material_cost+other_cost),0) c FROM v_request_cost", one=True)["c"]
    recent = q("""SELECT r.request_id, r.request_no, c.category_name, p.priority_name, r.status, r.created_at
                    FROM maintenance_request r JOIN category c USING(category_id) JOIN priority p USING(priority_id)
                   ORDER BY r.created_at DESC LIMIT 6""")
    load = q("SELECT * FROM v_technician_load ORDER BY active_jobs DESC LIMIT 5")
    return render_template("dashboard.html", counts=status_counts, totals=totals, cost=cost, recent=recent, load=load)


# --------------------------------------------------------------------------- requests: list / search
@app.route("/requests")
def requests_list():
    where, args = [], []
    s = request.args
    if s.get("q"):
        where.append("(r.request_no LIKE ? OR r.description LIKE ? OR rm.room_no LIKE ?)")
        args += [f"%{s['q']}%"] * 3
    for key, col in (("status", "r.status"), ("category", "r.category_id"), ("priority", "r.priority_id"),
                     ("building", "b.building_id")):
        if s.get(key):
            where.append(f"{col} = ?")
            args.append(s[key])
    sql = """SELECT r.request_id, r.request_no, b.building_name, rm.room_no, c.category_name, p.priority_name,
                    r.status, r.created_at
               FROM maintenance_request r
               JOIN room rm ON rm.room_id = r.room_id JOIN building b ON b.building_id = rm.building_id
               JOIN category c ON c.category_id = r.category_id JOIN priority p ON p.priority_id = r.priority_id"""
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY r.created_at DESC"
    return render_template("requests.html", rows=q(sql, args), f=s, **lookups())


def lookups():
    return dict(buildings=q("SELECT * FROM building ORDER BY building_name"),
                categories=q("SELECT * FROM category ORDER BY category_name"),
                priorities=q("SELECT * FROM priority ORDER BY rank_no"),
                statuses=["Open", "Assigned", "In Progress", "On Hold", "Resolved", "Closed", "Cancelled"])


# --------------------------------------------------------------------------- requests: create
@app.route("/requests/new", methods=["GET", "POST"])
def request_new():
    if request.method == "POST":
        def create():
            user = req_int("user_id", "Requester", 1)
            room = req_int("room_id", "Room", 1)
            cat = req_int("category_id", "Category", 1)
            pri = req_int("priority_id", "Priority", 1)
            asset = request.form.get("asset_id") or None
            text = req_text("description", 10, "Description")
            seq = q("SELECT COALESCE(MAX(request_id),0)+1 n FROM maintenance_request", one=True)["n"]
            no = f"MR-{datetime.now().year}-{seq:04d}"
            ts = now()
            cur = db().execute(
                """INSERT INTO maintenance_request(request_no,user_id,room_id,asset_id,category_id,priority_id,
                                                   description,created_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""", (no, user, room, asset, cat, pri, text, ts, ts))
            return cur.lastrowid, no
        res = run_tx(create, "Request logged successfully.")
        if res:
            return redirect(url_for("request_view", rid=res[0]))
    rooms = q("SELECT rm.room_id, rm.room_no, rm.room_type, rm.building_id FROM room rm ORDER BY rm.room_no")
    assets = q("SELECT asset_id, asset_tag, asset_name, room_id FROM asset ORDER BY asset_tag")
    users = q("SELECT user_id, full_name, role FROM app_user ORDER BY full_name")
    return render_template("request_new.html", rooms=rooms, assets=assets, users=users, **lookups())


# --------------------------------------------------------------------------- requests: view
def load_request(rid):
    r = q("""SELECT r.*, u.full_name requester, u.role, rm.room_no, rm.room_type, b.building_name,
                    c.category_name, p.priority_name, p.sla_hours, a.asset_tag, a.asset_name
               FROM maintenance_request r
               JOIN app_user u ON u.user_id = r.user_id
               JOIN room rm ON rm.room_id = r.room_id JOIN building b ON b.building_id = rm.building_id
               JOIN category c ON c.category_id = r.category_id JOIN priority p ON p.priority_id = r.priority_id
               LEFT JOIN asset a ON a.asset_id = r.asset_id
              WHERE r.request_id = ?""", (rid,), one=True)
    if r is None:
        abort(404)
    return r


@app.route("/requests/<int:rid>")
def request_view(rid):
    r = load_request(rid)
    active = q("""SELECT a.assignment_id, a.assigned_at, t.tech_name, t.hourly_rate FROM assignment a
                    JOIN technician t USING(tech_id) WHERE a.request_id=? AND a.is_active=1""", (rid,), one=True)
    assignments = q("""SELECT a.*, t.tech_name FROM assignment a JOIN technician t USING(tech_id)
                        WHERE a.request_id=? ORDER BY a.assigned_at""", (rid,))
    logs = q("""SELECT w.*, t.tech_name FROM work_log w JOIN assignment a USING(assignment_id)
                 JOIN technician t USING(tech_id) WHERE a.request_id=? ORDER BY w.log_time""", (rid,))
    mats = q("""SELECT rm.*, m.material_name, m.unit, ROUND(rm.quantity*rm.unit_cost_used,2) line_cost
                  FROM request_material rm JOIN material m USING(material_id) WHERE rm.request_id=?""", (rid,))
    costs = q("SELECT * FROM request_cost WHERE request_id=?", (rid,))
    history = q("SELECT * FROM status_history WHERE request_id=? ORDER BY history_id", (rid,))
    total = q("SELECT * FROM v_request_cost WHERE request_id=?", (rid,), one=True)
    fb = q("SELECT * FROM feedback WHERE request_id=?", (rid,), one=True)
    next_status = [x["to_status"] for x in q("SELECT to_status FROM status_transition WHERE from_status=?", (r["status"],))
                   if x["to_status"] not in ("Assigned", "Closed")]
    techs = q("""SELECT t.tech_id, t.tech_name, t.max_active_jobs, c.category_name,
                        (SELECT COUNT(*) FROM assignment a WHERE a.tech_id=t.tech_id AND a.is_active=1) active_jobs
                   FROM technician t JOIN category c USING(category_id) WHERE t.is_active=1
                  ORDER BY (t.category_id = ?) DESC, t.tech_name""", (r["category_id"],))
    materials = q("SELECT material_id, material_name, unit, stock_qty, unit_cost FROM material ORDER BY material_name")
    return render_template("request_view.html", r=r, active=active, assignments=assignments, logs=logs, mats=mats,
                           costs=costs, history=history, total=total, fb=fb, next_status=next_status,
                           techs=techs, materials=materials, **lookups())


# --------------------------------------------------------------------------- requests: actions
@app.post("/requests/<int:rid>/edit")
def request_edit(rid):
    def work():
        db().execute("UPDATE maintenance_request SET priority_id=?, description=?, updated_at=? WHERE request_id=?",
                     (req_int("priority_id", "Priority", 1), req_text("description", 10, "Description"), now(), rid))
    run_tx(work, "Request updated.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/assign")
def request_assign(rid):
    def work():
        db().execute("INSERT INTO assignment(request_id, tech_id, assigned_at) VALUES (?,?,?)",
                     (rid, req_int("tech_id", "Technician", 1), now()))
    run_tx(work, "Technician assigned; request moved to Assigned.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/unassign")
def request_unassign(rid):
    run_tx(lambda: db().execute("UPDATE maintenance_request SET status='Open', updated_at=? WHERE request_id=?",
                                (now(), rid)), "Technician released; request is Open again.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/status")
def request_status(rid):
    def work():
        new = req_text("new_status", 1, "New status")
        db().execute("UPDATE maintenance_request SET status=?, updated_at=? WHERE request_id=?", (new, now(), rid))
    run_tx(work, "Status updated.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/worklog")
def request_worklog(rid):
    def work():
        a = q("SELECT assignment_id FROM assignment WHERE request_id=? AND is_active=1", (rid,), one=True)
        if a is None:
            raise ValueError("No active technician assignment: assign a technician first.")
        db().execute("INSERT INTO work_log(assignment_id, log_time, work_done, hours_spent) VALUES (?,?,?,?)",
                     (a["assignment_id"], now(), req_text("work_done", 5, "Work description"),
                      req_num("hours_spent", "Hours spent", 0, 24)))
    run_tx(work, "Work log saved.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/material")
def request_material(rid):
    def work():
        mid = req_int("material_id", "Material", 1)
        qty = req_num("quantity", "Quantity", 0.0001)
        m = q("SELECT unit_cost FROM material WHERE material_id=?", (mid,), one=True)
        if m is None:
            raise ValueError("Unknown material.")
        db().execute("""INSERT INTO request_material(request_id, material_id, quantity, unit_cost_used, used_at)
                        VALUES (?,?,?,?,?)""", (rid, mid, qty, m["unit_cost"], now()))
    run_tx(work, "Material issued and stock updated.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/cost")
def request_cost(rid):
    def work():
        db().execute("INSERT INTO request_cost(request_id, cost_type, amount, remarks, recorded_at) VALUES (?,?,?,?,?)",
                     (rid, req_text("cost_type", 1, "Cost type"), req_num("amount", "Amount", 0),
                      request.form.get("remarks") or None, now()))
    run_tx(work, "Additional cost recorded.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/close")
def request_close(rid):
    def work():
        remarks = request.form.get("closure_remarks", "").strip() or None   # DB CHECK enforces the rule
        ts = now()
        db().execute("""UPDATE maintenance_request SET status='Closed', closure_remarks=?, closed_at=?, updated_at=?
                         WHERE request_id=?""", (remarks, ts, ts, rid))
    run_tx(work, "Request closed.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/feedback")
def request_feedback(rid):
    def work():
        db().execute("INSERT INTO feedback(request_id, rating, comments, submitted_at) VALUES (?,?,?,?)",
                     (rid, req_int("rating", "Rating", 1, 5), request.form.get("comments") or None, now()))
    run_tx(work, "Thank you - feedback recorded.")
    return redirect(url_for("request_view", rid=rid))


@app.post("/requests/<int:rid>/delete")
def request_delete(rid):
    ok = run_tx(lambda: db().execute("DELETE FROM maintenance_request WHERE request_id=?", (rid,)) and True,
                "Request deleted.")
    return redirect(url_for("requests_list") if ok else url_for("request_view", rid=rid))


# --------------------------------------------------------------------------- technicians & materials & locations
@app.route("/technicians", methods=["GET", "POST"])
def technicians():
    if request.method == "POST":
        run_tx(lambda: db().execute(
            "INSERT INTO technician(tech_name, category_id, phone, hourly_rate, max_active_jobs) VALUES (?,?,?,?,?)",
            (req_text("tech_name", 3, "Name"), req_int("category_id", "Specialization", 1),
             request.form.get("phone") or None, req_num("hourly_rate", "Hourly rate", 0),
             req_int("max_active_jobs", "Max active jobs", 1, 20))), "Technician added.")
        return redirect(url_for("technicians"))
    return render_template("technicians.html", rows=q("SELECT * FROM v_technician_load ORDER BY tech_name"), **lookups())


@app.post("/technicians/<int:tid>/toggle")
def technician_toggle(tid):
    run_tx(lambda: db().execute("UPDATE technician SET is_active = 1 - is_active WHERE tech_id=?", (tid,)),
           "Technician status changed.")
    return redirect(url_for("technicians"))


@app.route("/materials", methods=["GET", "POST"])
def materials():
    if request.method == "POST":
        run_tx(lambda: db().execute(
            "INSERT INTO material(material_name, unit, unit_cost, stock_qty) VALUES (?,?,?,?)",
            (req_text("material_name", 3, "Material name"), req_text("unit", 1, "Unit"),
             req_num("unit_cost", "Unit cost", 0), req_num("stock_qty", "Stock", 0))), "Material added.")
        return redirect(url_for("materials"))
    return render_template("materials.html", rows=q("SELECT * FROM material ORDER BY material_name"))


@app.post("/materials/<int:mid>/update")
def material_update(mid):
    run_tx(lambda: db().execute("UPDATE material SET unit_cost=?, stock_qty=? WHERE material_id=?",
                                (req_num("unit_cost", "Unit cost", 0), req_num("stock_qty", "Stock", 0), mid)),
           "Material updated.")
    return redirect(url_for("materials"))


@app.post("/materials/<int:mid>/delete")
def material_delete(mid):
    run_tx(lambda: db().execute("DELETE FROM material WHERE material_id=?", (mid,)), "Material deleted.")
    return redirect(url_for("materials"))


@app.route("/locations", methods=["GET", "POST"])
def locations():
    if request.method == "POST":
        kind = request.form.get("kind")

        def work():
            if kind == "building":
                db().execute("INSERT INTO building(building_code, building_name, floors) VALUES (?,?,?)",
                             (req_text("code", 2, "Code").upper(), req_text("name", 3, "Name"), req_int("floors", "Floors", 1, 60)))
            elif kind == "room":
                db().execute("INSERT INTO room(building_id, room_no, room_type) VALUES (?,?,?)",
                             (req_int("building_id", "Building", 1), req_text("room_no", 1, "Room no."), req_text("room_type", 1, "Type")))
            elif kind == "asset":
                db().execute("INSERT INTO asset(room_id, asset_tag, asset_name, asset_type) VALUES (?,?,?,?)",
                             (req_int("room_id", "Room", 1), req_text("asset_tag", 3, "Asset tag"),
                              req_text("asset_name", 3, "Asset name"), req_text("asset_type", 1, "Asset type")))
        run_tx(work, "Location record added.")
        return redirect(url_for("locations"))
    rows = q("""SELECT b.building_id, b.building_code, b.building_name, b.floors,
                       (SELECT COUNT(*) FROM room r WHERE r.building_id=b.building_id) rooms,
                       (SELECT COUNT(*) FROM asset a JOIN room r USING(room_id) WHERE r.building_id=b.building_id) assets
                  FROM building b ORDER BY b.building_name""")
    rooms = q("SELECT rm.room_id, rm.room_no, b.building_code FROM room rm JOIN building b USING(building_id) ORDER BY b.building_code, rm.room_no")
    return render_template("locations.html", rows=rows, rooms=rooms, **lookups())


@app.post("/locations/building/<int:bid>/delete")
def building_delete(bid):
    run_tx(lambda: db().execute("DELETE FROM building WHERE building_id=?", (bid,)), "Building deleted.")
    return redirect(url_for("locations"))


# --------------------------------------------------------------------------- reports
REPORTS = {
    "pending": ("Pending Requests", "SELECT request_no, building_name, room_no, category_name, priority_name, status, technician, created_at FROM v_pending_requests",
                "View with 5-table JOIN and correlated sub-query"),
    "ageing": ("Ageing of Pending Requests", "SELECT age_bucket, COUNT(*) requests, ROUND(AVG(age_days),1) avg_age_days, MAX(age_days) oldest_days FROM v_request_ageing GROUP BY age_bucket ORDER BY MIN(age_days)",
                "GROUP BY over a view, julianday() date arithmetic"),
    "response": ("Response Time and SLA", "SELECT request_no, priority_name, sla_hours, response_hours, sla_status FROM v_response_time ORDER BY response_hours DESC LIMIT 15",
                 "JOIN + MIN() aggregate + CASE"),
    "load": ("Technician Load", "SELECT tech_name, specialization, active_jobs, max_active_jobs, total_jobs_handled, hours_logged FROM v_technician_load ORDER BY active_jobs DESC, tech_name",
             "LEFT JOIN, conditional COUNT, scalar sub-query"),
    "cost": ("Building-wise Maintenance Cost", "SELECT building_name, requests, labour, material, other, total_cost FROM v_building_cost",
             "View over view, SUM() with GROUP BY"),
    "material": ("Material Use", "SELECT material_name, unit, qty_used, value_used, stock_left FROM v_material_use",
                 "LEFT JOIN + SUM(qty x cost)"),
    "feedback": ("Feedback Summary", "SELECT category_name, responses, avg_rating, lowest, highest FROM v_feedback_summary ORDER BY avg_rating DESC",
                 "Two LEFT JOINs + AVG()"),
    "nested": ("Requests Costlier than the Average (nested query)",
               """SELECT vc.request_no, ROUND(vc.labour_cost+vc.material_cost+vc.other_cost,2) AS total_cost
                    FROM v_request_cost vc
                   WHERE vc.labour_cost+vc.material_cost+vc.other_cost >
                         (SELECT AVG(labour_cost+material_cost+other_cost) FROM v_request_cost WHERE labour_cost>0)
                   ORDER BY total_cost DESC""",
               "Nested sub-query with AVG()"),
}


@app.route("/reports")
@app.route("/reports/<key>")
def reports(key="pending"):
    if key not in REPORTS:
        abort(404)
    title, sql, concept = REPORTS[key]
    cur = db().execute(sql)
    cols = [d[0] for d in cur.description]
    return render_template("reports.html", key=key, title=title, concept=concept, cols=cols, rows=cur.fetchall(),
                           nav=[(k, v[0]) for k, v in REPORTS.items()], sql=re.sub(r"\s+", " ", sql).strip())


@app.template_filter("money")
def money(v):
    return f"{v:,.0f}" if v is not None else "0"


if __name__ == "__main__":
    app.run(debug=False, port=5000)
