"""Generates 02_sample_data.sql.

Master data is inserted directly.  The 40 maintenance requests are driven through the
real workflow (INSERT request -> INSERT assignment -> INSERT materials / work_log ->
UPDATE status ...) so that every trigger in 01_schema.sql fires exactly as it does when
the application is used.  Timestamps are explicit literals relative to the generation date.
"""
import random
from datetime import datetime, timedelta

rnd = random.Random(2026)
NOW = datetime(2026, 10, 12, 8, 30)          # anchor = demonstration date
out = []


def q(v):
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def ins(table, cols, rows):
    out.append(f"INSERT INTO {table} ({', '.join(cols)}) VALUES")
    out.append(",\n".join("  (" + ", ".join(q(x) for x in r) + ")" for r in rows) + ";\n")


def ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


out.append("-- 02_sample_data.sql : master data + 40 requests driven through the workflow\nPRAGMA foreign_keys = ON;\n")

# ---------------- master data ----------------
buildings = [("ACB", "Academic Block A", 4), ("LIB", "Central Library", 3), ("SCI", "Science and Lab Block", 3),
             ("HST", "Boys Hostel", 5), ("ADM", "Administration Block", 2)]
ins("building", ["building_code", "building_name", "floors"], buildings)

rooms = []
room_defs = {
    1: [("A-101", "Classroom"), ("A-102", "Classroom"), ("A-204", "Classroom"), ("A-LH1", "Auditorium")],
    2: [("L-G01", "Office"), ("L-RR1", "Classroom"), ("L-WS1", "Washroom"), ("L-201", "Classroom")],
    3: [("S-L01", "Laboratory"), ("S-L02", "Laboratory"), ("S-WS1", "Washroom"), ("S-105", "Classroom")],
    4: [("H-101", "Hostel Room"), ("H-214", "Hostel Room"), ("H-WS2", "Washroom"), ("H-COR3", "Corridor")],
    5: [("D-001", "Office"), ("D-012", "Office"), ("D-WS1", "Washroom"), ("D-105", "Office")],
}
for b, lst in room_defs.items():
    for no, typ in lst:
        rooms.append((b, no, typ))
ins("room", ["building_id", "room_no", "room_type"], rooms)
# room_id = position in list (1..20)

assets = [
    (1, "AST-0001", "Ceiling Fan A-101", "Electrical"), (1, "AST-0002", "LED Projector A-101", "IT/AV"),
    (2, "AST-0003", "Split AC A-102", "HVAC"), (2, "AST-0004", "Student Bench Set A-102", "Furniture"),
    (3, "AST-0005", "Tube Light Panel A-204", "Electrical"), (3, "AST-0006", "Smart Board A-204", "IT/AV"),
    (4, "AST-0007", "Auditorium Sound System", "IT/AV"), (4, "AST-0008", "Auditorium AC Unit 2", "HVAC"),
    (5, "AST-0009", "Reception Desk", "Furniture"), (6, "AST-0010", "Reading Room Fan R1", "Electrical"),
    (7, "AST-0011", "Washbasin Tap L-WS1", "Plumbing"), (7, "AST-0012", "Flush Tank L-WS1", "Plumbing"),
    (8, "AST-0013", "Library Chair Set 201", "Furniture"), (9, "AST-0014", "Fume Hood S-L01", "HVAC"),
    (9, "AST-0015", "Lab Workbench S-L01", "Furniture"), (10, "AST-0016", "Lab Power Panel S-L02", "Electrical"),
    (11, "AST-0017", "Washroom Water Line S-WS1", "Plumbing"), (12, "AST-0018", "Classroom Window S-105", "Civil"),
    (13, "AST-0019", "Hostel Cot H-101", "Furniture"), (13, "AST-0020", "Hostel Fan H-101", "Electrical"),
    (14, "AST-0021", "Hostel Geyser H-214", "Electrical"), (15, "AST-0022", "Shower Mixer H-WS2", "Plumbing"),
    (16, "AST-0023", "Corridor Light H-COR3", "Electrical"), (17, "AST-0024", "Admin Split AC D-001", "HVAC"),
    (18, "AST-0025", "Office Cupboard D-012", "Furniture"), (19, "AST-0026", "Wash Basin D-WS1", "Plumbing"),
    (20, "AST-0027", "Office Door Lock D-105", "Civil"), (20, "AST-0028", "Network Switch D-105", "IT/AV"),
]
ins("asset", ["room_id", "asset_tag", "asset_name", "asset_type"], assets)

users = [
    ("Aarav Mehta", "aarav.mehta@campus.edu", "9876500001", "Student"),
    ("Sneha Reddy", "sneha.reddy@campus.edu", "9876500002", "Student"),
    ("Dr. Kavitha Rao", "kavitha.rao@campus.edu", "9876500003", "Faculty"),
    ("Prof. Imran Khan", "imran.khan@campus.edu", "9876500004", "Faculty"),
    ("Rohit Sharma", "rohit.sharma@campus.edu", "9876500005", "Student"),
    ("Neha Gupta", "neha.gupta@campus.edu", "9876500006", "Student"),
    ("Suresh Babu", "suresh.babu@campus.edu", "9876500007", "Staff"),
    ("Lakshmi Devi", "lakshmi.devi@campus.edu", "9876500008", "Staff"),
    ("Dr. Anil Verma", "anil.verma@campus.edu", "9876500009", "Faculty"),
    ("Pooja Nair", "pooja.nair@campus.edu", "9876500010", "Student"),
    ("Vikram Singh", "vikram.singh@campus.edu", "9876500011", "Student"),
    ("Facility Desk", "facility.desk@campus.edu", "9876500012", "Facility Admin"),
]
ins("app_user", ["full_name", "email", "phone", "role"], users)

cats = ["Electrical", "Plumbing", "Furniture", "HVAC", "IT/AV", "Civil"]
ins("category", ["category_name"], [(c,) for c in cats])
CAT = {c: i + 1 for i, c in enumerate(cats)}

pris = [("Critical", 1, 4), ("High", 2, 24), ("Medium", 3, 72), ("Low", 4, 120)]
ins("priority", ["priority_name", "rank_no", "sla_hours"], pris)
PRI_SLA = {i + 1: p[2] for i, p in enumerate(pris)}

techs = [  # name, category, phone, rate, max jobs
    ("Ramesh Kumar", "Electrical", "9988700001", 300, 4), ("Sanjay Patil", "Electrical", "9988700002", 280, 4),
    ("Mahesh Yadav", "Plumbing", "9988700003", 260, 4), ("Iqbal Hussain", "Plumbing", "9988700004", 260, 3),
    ("Gopal Naidu", "Furniture", "9988700005", 240, 5), ("Praveen Joshi", "HVAC", "9988700006", 350, 3),
    ("Anita Das", "IT/AV", "9988700007", 400, 4), ("Bhaskar Rao", "Civil", "9988700008", 270, 4),
]
ins("technician", ["tech_name", "category_id", "phone", "hourly_rate", "max_active_jobs"],
    [(t[0], CAT[t[1]], t[2], t[3], t[4]) for t in techs])
TECH = [{"id": i + 1, "cat": t[1], "rate": t[3], "max": t[4], "active": 0} for i, t in enumerate(techs)]

mats = [  # name, unit, cost, stock
    ("LED Tube Light 18W", "pcs", 180, 60), ("Ceiling Fan Capacitor", "pcs", 95, 40), ("Copper Wire 2.5mm", "m", 38, 300),
    ("MCB 16A", "pcs", 220, 30), ("PVC Pipe 1 inch", "m", 85, 120), ("Tap Cartridge", "pcs", 310, 25),
    ("Flush Valve", "pcs", 540, 15), ("Teflon Tape", "pcs", 25, 80), ("Plywood Sheet 12mm", "sheet", 1450, 12),
    ("Wood Screws Pack", "pack", 60, 70), ("AC Gas R32", "kg", 650, 20), ("AC Filter", "pcs", 420, 18),
    ("HDMI Cable 5m", "pcs", 380, 14), ("Door Lock Set", "pcs", 950, 10), ("Cement Bag 50kg", "bag", 410, 20),
]
ins("material", ["material_name", "unit", "unit_cost", "stock_qty"], mats)
MAT_COST = {i + 1: m[2] for i, m in enumerate(mats)}
MAT_BY_CAT = {"Electrical": [1, 2, 3, 4], "Plumbing": [5, 6, 7, 8], "Furniture": [9, 10], "HVAC": [11, 12],
              "IT/AV": [13], "Civil": [14, 15]}
mat_stock = {i + 1: m[3] for i, m in enumerate(mats)}

transitions = [("Open", "Assigned"), ("Open", "Cancelled"), ("Assigned", "In Progress"), ("Assigned", "On Hold"),
               ("Assigned", "Open"), ("Assigned", "Cancelled"), ("In Progress", "On Hold"), ("In Progress", "Resolved"),
               ("On Hold", "In Progress"), ("On Hold", "Cancelled"), ("Resolved", "Closed"), ("Resolved", "Open")]
ins("status_transition", ["from_status", "to_status"], transitions)

# ---------------- request workflow ----------------
desc = {
    "Electrical": ["Ceiling fan not working and making noise", "Tube lights flickering in the room",
                   "Power socket sparking near the desk", "Corridor light fused and needs replacement"],
    "Plumbing": ["Water leakage from the washbasin tap", "Flush tank not filling properly",
                 "Blocked drain causing water stagnation", "Low water pressure in the shower"],
    "Furniture": ["Broken bench legs in the classroom", "Cupboard door hinge broken",
                  "Chair seat damaged and unsafe to use", "Cot frame loose and unstable"],
    "HVAC": ["Split AC not cooling the room", "AC making loud noise during operation",
             "Fume hood extraction too weak", "AC water dripping inside the room"],
    "IT/AV": ["Projector display flickering and dim", "Smart board touch not responding",
              "Network switch ports not working", "Auditorium microphone has no sound"],
    "Civil": ["Window latch broken and glass loose", "Door lock jammed and key stuck",
              "Ceiling plaster peeling near the corner", "Crack on wall near the entrance"],
}
cat_weights = ["Electrical"] * 8 + ["Plumbing"] * 7 + ["Furniture"] * 6 + ["HVAC"] * 6 + ["IT/AV"] * 6 + ["Civil"] * 7
asset_by_type = {}
for i, a in enumerate(assets):
    asset_by_type.setdefault(a[3], []).append((i + 1, a[0]))
asset_room = {i + 1: a[0] for i, a in enumerate(assets)}

# target final states for the 40 requests
plan = (["Closed"] * 17 + ["Resolved"] * 3 + ["In Progress"] * 6 + ["Assigned"] * 4 + ["On Hold"] * 2 +
        ["Open"] * 6 + ["Cancelled"] * 2)
rnd.shuffle(plan)
closure_notes = ["Work completed and verified by the requester", "Replaced faulty part and tested successfully",
                 "Issue fixed; area cleaned and handed over", "Repaired and tested in presence of the user",
                 "Completed as per request; no further action needed"]
fb_comments = ["Quick and neat work", "Fixed well but arrived late", "Satisfied with the service",
               "Problem fixed on the first visit", "Needed a second visit", "Excellent technician behaviour"]
other_types = ["Contractor", "Transport", "Disposal", "Other"]

# sort by age so request numbers rise with creation date
days_back = sorted([rnd.uniform(1, 44) for _ in plan], reverse=True)
out.append("-- ---- 40 requests driven through the workflow ----")
for n, (state, d) in enumerate(zip(plan, days_back), start=1):
    created = NOW - timedelta(days=d)
    if state in ("Resolved", "Closed"):
        created = min(created, NOW - timedelta(days=5))
    cat = rnd.choice(cat_weights)
    user = rnd.randint(1, 12)
    if asset_by_type.get(cat) and rnd.random() < 0.7:
        asset, room = rnd.choice(asset_by_type[cat])
    else:
        asset, room = None, rnd.randint(1, 20)
    pri = rnd.choices([1, 2, 3, 4], weights=[1, 3, 4, 2])[0]
    req_no = f"MR-2026-{n:04d}"
    d_txt = rnd.choice(desc[cat])
    out.append(f"\n-- {req_no} [{cat}] target state: {state}")
    out.append("INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, "
               "description, status, created_at, updated_at) VALUES "
               f"({q(req_no)}, {user}, {room}, {q(asset)}, {CAT[cat]}, {pri}, {q(d_txt)}, 'Open', {q(ts(created))}, {q(ts(created))});")
    rid = n  # request_id follows insertion order
    if state == "Open":
        continue
    if state == "Cancelled":
        out.append(f"UPDATE maintenance_request SET status='Cancelled', updated_at={q(ts(created + timedelta(hours=6)))} WHERE request_id={rid};")
        continue
    # choose technician of the matching category with spare capacity
    cands = [t for t in TECH if t["cat"] == cat and t["active"] < t["max"]]
    sla = PRI_SLA[pri]
    resp_h = max(0.4, sla * rnd.uniform(0.15, 1.5))
    assigned = created + timedelta(hours=resp_h)
    if state in ("Closed", "Resolved"):
        tech = rnd.choice([t for t in TECH if t["cat"] == cat])   # job finished -> capacity freed
    elif cands:
        tech = min(cands, key=lambda t: t["active"])
        tech["active"] += 1
    else:                                  # no capacity: request waits in Open (assignment control)
        continue
    out.append(f"INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES ({rid}, {tech['id']}, {q(ts(assigned))});")
    t_cur = assigned
    # materials (issued while Assigned / In Progress)
    mat_lines = []
    if rnd.random() < 0.75:
        for mid in rnd.sample(MAT_BY_CAT[cat], k=min(len(MAT_BY_CAT[cat]), rnd.randint(1, 2))):
            qty = rnd.choice([1, 1, 2, 3]) if mats[mid - 1][1] != "m" else rnd.choice([5, 10, 15])
            if mat_stock[mid] >= qty:
                mat_stock[mid] -= qty
                mat_lines.append((mid, qty))
    if state == "Assigned":
        for mid, qty in mat_lines[:1]:
            out.append("INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES "
                       f"({rid}, {mid}, {qty}, {MAT_COST[mid]}, {q(ts(t_cur + timedelta(hours=2)))});")
        continue
    # work logs
    n_logs = rnd.randint(1, 3)
    total_h = 0
    for k in range(n_logs):
        t_cur = t_cur + timedelta(hours=rnd.uniform(3, 20))
        hrs = round(rnd.uniform(0.5, 3.5), 1)
        total_h += hrs
        out.append("INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES "
                   f"((SELECT assignment_id FROM assignment WHERE request_id={rid} ORDER BY assignment_id DESC LIMIT 1), "
                   f"{q(ts(t_cur))}, {q(rnd.choice(['Inspected the fault and isolated the problem', 'Replaced the defective component', 'Testing and final adjustment', 'Cleaned the area after repair']))}, {hrs});")
        if k == 0:
            for mid, qty in mat_lines:
                out.append("INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES "
                           f"({rid}, {mid}, {qty}, {MAT_COST[mid]}, {q(ts(t_cur + timedelta(minutes=20)))});")
    if rnd.random() < 0.22:
        out.append("INSERT INTO request_cost (request_id, cost_type, amount, remarks, recorded_at) VALUES "
                   f"({rid}, {q(rnd.choice(other_types))}, {rnd.choice([150, 300, 450, 800, 1200])}, 'External charge', {q(ts(t_cur))});")
    if state == "On Hold":
        out.append(f"UPDATE maintenance_request SET status='On Hold', updated_at={q(ts(t_cur + timedelta(hours=1)))} WHERE request_id={rid};")
        continue
    if state == "In Progress":
        continue
    t_cur += timedelta(hours=rnd.uniform(1, 6))
    out.append(f"UPDATE maintenance_request SET status='Resolved', updated_at={q(ts(t_cur))} WHERE request_id={rid};")
    if state == "Closed":
        t_close = t_cur + timedelta(hours=rnd.uniform(2, 30))
        out.append("UPDATE maintenance_request SET status='Closed', "
                   f"closed_at={q(ts(t_close))}, closure_remarks={q(rnd.choice(closure_notes))}, updated_at={q(ts(t_close))} WHERE request_id={rid};")
        if rnd.random() < 0.85:
            out.append("INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES "
                       f"({rid}, {rnd.choices([2, 3, 4, 5], weights=[1, 2, 5, 5])[0]}, {q(rnd.choice(fb_comments))}, {q(ts(t_close + timedelta(hours=rnd.uniform(1, 40))))});")

open("/home/claude/proj/db/02_sample_data.sql", "w").write("\n".join(out) + "\n")
print("generated", len(out), "lines")
