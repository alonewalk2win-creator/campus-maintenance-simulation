-- 02_sample_data.sql : master data + 40 requests driven through the workflow
PRAGMA foreign_keys = ON;

INSERT INTO building (building_code, building_name, floors) VALUES
  ('ACB', 'Academic Block A', 4),
  ('LIB', 'Central Library', 3),
  ('SCI', 'Science and Lab Block', 3),
  ('HST', 'Boys Hostel', 5),
  ('ADM', 'Administration Block', 2);

INSERT INTO room (building_id, room_no, room_type) VALUES
  (1, 'A-101', 'Classroom'),
  (1, 'A-102', 'Classroom'),
  (1, 'A-204', 'Classroom'),
  (1, 'A-LH1', 'Auditorium'),
  (2, 'L-G01', 'Office'),
  (2, 'L-RR1', 'Classroom'),
  (2, 'L-WS1', 'Washroom'),
  (2, 'L-201', 'Classroom'),
  (3, 'S-L01', 'Laboratory'),
  (3, 'S-L02', 'Laboratory'),
  (3, 'S-WS1', 'Washroom'),
  (3, 'S-105', 'Classroom'),
  (4, 'H-101', 'Hostel Room'),
  (4, 'H-214', 'Hostel Room'),
  (4, 'H-WS2', 'Washroom'),
  (4, 'H-COR3', 'Corridor'),
  (5, 'D-001', 'Office'),
  (5, 'D-012', 'Office'),
  (5, 'D-WS1', 'Washroom'),
  (5, 'D-105', 'Office');

INSERT INTO asset (room_id, asset_tag, asset_name, asset_type) VALUES
  (1, 'AST-0001', 'Ceiling Fan A-101', 'Electrical'),
  (1, 'AST-0002', 'LED Projector A-101', 'IT/AV'),
  (2, 'AST-0003', 'Split AC A-102', 'HVAC'),
  (2, 'AST-0004', 'Student Bench Set A-102', 'Furniture'),
  (3, 'AST-0005', 'Tube Light Panel A-204', 'Electrical'),
  (3, 'AST-0006', 'Smart Board A-204', 'IT/AV'),
  (4, 'AST-0007', 'Auditorium Sound System', 'IT/AV'),
  (4, 'AST-0008', 'Auditorium AC Unit 2', 'HVAC'),
  (5, 'AST-0009', 'Reception Desk', 'Furniture'),
  (6, 'AST-0010', 'Reading Room Fan R1', 'Electrical'),
  (7, 'AST-0011', 'Washbasin Tap L-WS1', 'Plumbing'),
  (7, 'AST-0012', 'Flush Tank L-WS1', 'Plumbing'),
  (8, 'AST-0013', 'Library Chair Set 201', 'Furniture'),
  (9, 'AST-0014', 'Fume Hood S-L01', 'HVAC'),
  (9, 'AST-0015', 'Lab Workbench S-L01', 'Furniture'),
  (10, 'AST-0016', 'Lab Power Panel S-L02', 'Electrical'),
  (11, 'AST-0017', 'Washroom Water Line S-WS1', 'Plumbing'),
  (12, 'AST-0018', 'Classroom Window S-105', 'Civil'),
  (13, 'AST-0019', 'Hostel Cot H-101', 'Furniture'),
  (13, 'AST-0020', 'Hostel Fan H-101', 'Electrical'),
  (14, 'AST-0021', 'Hostel Geyser H-214', 'Electrical'),
  (15, 'AST-0022', 'Shower Mixer H-WS2', 'Plumbing'),
  (16, 'AST-0023', 'Corridor Light H-COR3', 'Electrical'),
  (17, 'AST-0024', 'Admin Split AC D-001', 'HVAC'),
  (18, 'AST-0025', 'Office Cupboard D-012', 'Furniture'),
  (19, 'AST-0026', 'Wash Basin D-WS1', 'Plumbing'),
  (20, 'AST-0027', 'Office Door Lock D-105', 'Civil'),
  (20, 'AST-0028', 'Network Switch D-105', 'IT/AV');

INSERT INTO app_user (full_name, email, phone, role) VALUES
  ('Aarav Mehta', 'aarav.mehta@campus.edu', '9876500001', 'Student'),
  ('Sneha Reddy', 'sneha.reddy@campus.edu', '9876500002', 'Student'),
  ('Dr. Kavitha Rao', 'kavitha.rao@campus.edu', '9876500003', 'Faculty'),
  ('Prof. Imran Khan', 'imran.khan@campus.edu', '9876500004', 'Faculty'),
  ('Rohit Sharma', 'rohit.sharma@campus.edu', '9876500005', 'Student'),
  ('Neha Gupta', 'neha.gupta@campus.edu', '9876500006', 'Student'),
  ('Suresh Babu', 'suresh.babu@campus.edu', '9876500007', 'Staff'),
  ('Lakshmi Devi', 'lakshmi.devi@campus.edu', '9876500008', 'Staff'),
  ('Dr. Anil Verma', 'anil.verma@campus.edu', '9876500009', 'Faculty'),
  ('Pooja Nair', 'pooja.nair@campus.edu', '9876500010', 'Student'),
  ('Vikram Singh', 'vikram.singh@campus.edu', '9876500011', 'Student'),
  ('Facility Desk', 'facility.desk@campus.edu', '9876500012', 'Facility Admin');

INSERT INTO category (category_name) VALUES
  ('Electrical'),
  ('Plumbing'),
  ('Furniture'),
  ('HVAC'),
  ('IT/AV'),
  ('Civil');

INSERT INTO priority (priority_name, rank_no, sla_hours) VALUES
  ('Critical', 1, 4),
  ('High', 2, 24),
  ('Medium', 3, 72),
  ('Low', 4, 120);

INSERT INTO technician (tech_name, category_id, phone, hourly_rate, max_active_jobs) VALUES
  ('Ramesh Kumar', 1, '9988700001', 300, 4),
  ('Sanjay Patil', 1, '9988700002', 280, 4),
  ('Mahesh Yadav', 2, '9988700003', 260, 4),
  ('Iqbal Hussain', 2, '9988700004', 260, 3),
  ('Gopal Naidu', 3, '9988700005', 240, 5),
  ('Praveen Joshi', 4, '9988700006', 350, 3),
  ('Anita Das', 5, '9988700007', 400, 4),
  ('Bhaskar Rao', 6, '9988700008', 270, 4);

INSERT INTO material (material_name, unit, unit_cost, stock_qty) VALUES
  ('LED Tube Light 18W', 'pcs', 180, 60),
  ('Ceiling Fan Capacitor', 'pcs', 95, 40),
  ('Copper Wire 2.5mm', 'm', 38, 300),
  ('MCB 16A', 'pcs', 220, 30),
  ('PVC Pipe 1 inch', 'm', 85, 120),
  ('Tap Cartridge', 'pcs', 310, 25),
  ('Flush Valve', 'pcs', 540, 15),
  ('Teflon Tape', 'pcs', 25, 80),
  ('Plywood Sheet 12mm', 'sheet', 1450, 12),
  ('Wood Screws Pack', 'pack', 60, 70),
  ('AC Gas R32', 'kg', 650, 20),
  ('AC Filter', 'pcs', 420, 18),
  ('HDMI Cable 5m', 'pcs', 380, 14),
  ('Door Lock Set', 'pcs', 950, 10),
  ('Cement Bag 50kg', 'bag', 410, 20);

INSERT INTO status_transition (from_status, to_status) VALUES
  ('Open', 'Assigned'),
  ('Open', 'Cancelled'),
  ('Assigned', 'In Progress'),
  ('Assigned', 'On Hold'),
  ('Assigned', 'Open'),
  ('Assigned', 'Cancelled'),
  ('In Progress', 'On Hold'),
  ('In Progress', 'Resolved'),
  ('On Hold', 'In Progress'),
  ('On Hold', 'Cancelled'),
  ('Resolved', 'Closed'),
  ('Resolved', 'Open');

-- ---- 40 requests driven through the workflow ----

-- MR-2026-0001 [Furniture] target state: In Progress
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0001', 9, 17, NULL, 3, 3, 'Cot frame loose and unstable', 'Open', '2026-08-29 21:40:59', '2026-08-29 21:40:59');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (1, 5, '2026-09-01 02:34:38');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=1 ORDER BY assignment_id DESC LIMIT 1), '2026-09-01 21:20:07', 'Replaced the defective component', 1.6);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (1, 9, 1, 1450, '2026-09-01 21:40:07');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (1, 10, 3, 60, '2026-09-01 21:40:07');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=1 ORDER BY assignment_id DESC LIMIT 1), '2026-09-02 04:45:26', 'Cleaned the area after repair', 2.0);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=1 ORDER BY assignment_id DESC LIMIT 1), '2026-09-02 21:29:33', 'Inspected the fault and isolated the problem', 2.2);

-- MR-2026-0002 [Furniture] target state: In Progress
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0002', 8, 4, NULL, 3, 3, 'Chair seat damaged and unsafe to use', 'Open', '2026-09-01 09:17:32', '2026-09-01 09:17:32');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (2, 5, '2026-09-03 16:06:58');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=2 ORDER BY assignment_id DESC LIMIT 1), '2026-09-04 09:26:16', 'Inspected the fault and isolated the problem', 1.9);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=2 ORDER BY assignment_id DESC LIMIT 1), '2026-09-04 23:27:47', 'Testing and final adjustment', 3.2);
INSERT INTO request_cost (request_id, cost_type, amount, remarks, recorded_at) VALUES (2, 'Other', 300, 'External charge', '2026-09-04 23:27:47');

-- MR-2026-0003 [IT/AV] target state: On Hold
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0003', 1, 20, 28, 5, 3, 'Projector display flickering and dim', 'Open', '2026-09-01 12:37:38', '2026-09-01 12:37:38');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (3, 7, '2026-09-04 10:43:56');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=3 ORDER BY assignment_id DESC LIMIT 1), '2026-09-05 02:36:45', 'Inspected the fault and isolated the problem', 1.6);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (3, 13, 2, 380, '2026-09-05 02:56:45');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=3 ORDER BY assignment_id DESC LIMIT 1), '2026-09-05 10:56:28', 'Cleaned the area after repair', 2.2);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=3 ORDER BY assignment_id DESC LIMIT 1), '2026-09-06 01:40:01', 'Replaced the defective component', 3.3);
UPDATE maintenance_request SET status='On Hold', updated_at='2026-09-06 02:40:01' WHERE request_id=3;

-- MR-2026-0004 [Plumbing] target state: Open
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0004', 10, 17, NULL, 2, 2, 'Low water pressure in the shower', 'Open', '2026-09-01 22:24:33', '2026-09-01 22:24:33');

-- MR-2026-0005 [Plumbing] target state: Assigned
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0005', 3, 19, NULL, 2, 2, 'Low water pressure in the shower', 'Open', '2026-09-03 05:17:49', '2026-09-03 05:17:49');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (5, 3, '2026-09-03 21:32:46');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (5, 8, 1, 25, '2026-09-03 23:32:46');

-- MR-2026-0006 [Electrical] target state: Cancelled
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0006', 7, 2, NULL, 1, 4, 'Power socket sparking near the desk', 'Open', '2026-09-03 06:13:45', '2026-09-03 06:13:45');
UPDATE maintenance_request SET status='Cancelled', updated_at='2026-09-03 12:13:45' WHERE request_id=6;

-- MR-2026-0007 [Electrical] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0007', 1, 6, 10, 1, 3, 'Corridor light fused and needs replacement', 'Open', '2026-09-03 15:58:40', '2026-09-03 15:58:40');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (7, 1, '2026-09-05 10:28:09');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=7 ORDER BY assignment_id DESC LIMIT 1), '2026-09-05 19:11:18', 'Inspected the fault and isolated the problem', 2.3);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (7, 2, 1, 95, '2026-09-05 19:31:18');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (7, 1, 3, 180, '2026-09-05 19:31:18');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=7 ORDER BY assignment_id DESC LIMIT 1), '2026-09-06 07:29:36', 'Replaced the defective component', 0.6);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=7 ORDER BY assignment_id DESC LIMIT 1), '2026-09-06 11:15:45', 'Inspected the fault and isolated the problem', 2.1);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-06 16:02:09' WHERE request_id=7;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-06 23:18:53', closure_remarks='Work completed and verified by the requester', updated_at='2026-09-06 23:18:53' WHERE request_id=7;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (7, 4, 'Needed a second visit', '2026-09-08 11:12:17');

-- MR-2026-0008 [Plumbing] target state: In Progress
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0008', 3, 7, 12, 2, 2, 'Low water pressure in the shower', 'Open', '2026-09-09 02:20:54', '2026-09-09 02:20:54');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (8, 4, '2026-09-09 23:13:05');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=8 ORDER BY assignment_id DESC LIMIT 1), '2026-09-10 07:24:05', 'Testing and final adjustment', 1.5);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=8 ORDER BY assignment_id DESC LIMIT 1), '2026-09-10 18:17:17', 'Cleaned the area after repair', 3.5);

-- MR-2026-0009 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0009', 6, 15, 22, 2, 2, 'Blocked drain causing water stagnation', 'Open', '2026-09-10 18:53:24', '2026-09-10 18:53:24');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (9, 3, '2026-09-12 00:56:00');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=9 ORDER BY assignment_id DESC LIMIT 1), '2026-09-12 13:11:57', 'Replaced the defective component', 3.0);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (9, 8, 2, 25, '2026-09-12 13:31:57');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=9 ORDER BY assignment_id DESC LIMIT 1), '2026-09-13 08:32:23', 'Replaced the defective component', 1.6);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-13 12:58:32' WHERE request_id=9;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-14 13:08:45', closure_remarks='Replaced faulty part and tested successfully', updated_at='2026-09-14 13:08:45' WHERE request_id=9;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (9, 5, 'Needed a second visit', '2026-09-15 19:26:40');

-- MR-2026-0010 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0010', 10, 11, 17, 2, 3, 'Flush tank not filling properly', 'Open', '2026-09-11 01:17:17', '2026-09-11 01:17:17');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (10, 4, '2026-09-11 21:56:58');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=10 ORDER BY assignment_id DESC LIMIT 1), '2026-09-12 14:35:20', 'Inspected the fault and isolated the problem', 2.4);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (10, 6, 1, 310, '2026-09-12 14:55:20');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (10, 5, 10, 85, '2026-09-12 14:55:20');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=10 ORDER BY assignment_id DESC LIMIT 1), '2026-09-13 02:12:06', 'Inspected the fault and isolated the problem', 1.3);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=10 ORDER BY assignment_id DESC LIMIT 1), '2026-09-13 10:08:57', 'Testing and final adjustment', 1.4);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-13 11:13:07' WHERE request_id=10;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-14 13:28:49', closure_remarks='Issue fixed; area cleaned and handed over', updated_at='2026-09-14 13:28:49' WHERE request_id=10;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (10, 2, 'Quick and neat work', '2026-09-14 23:39:15');

-- MR-2026-0011 [Furniture] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0011', 2, 13, 19, 3, 3, 'Chair seat damaged and unsafe to use', 'Open', '2026-09-11 01:59:50', '2026-09-11 01:59:50');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (11, 5, '2026-09-12 19:24:45');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=11 ORDER BY assignment_id DESC LIMIT 1), '2026-09-13 02:04:42', 'Inspected the fault and isolated the problem', 1.9);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (11, 10, 2, 60, '2026-09-13 02:24:42');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=11 ORDER BY assignment_id DESC LIMIT 1), '2026-09-13 16:44:54', 'Testing and final adjustment', 3.1);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=11 ORDER BY assignment_id DESC LIMIT 1), '2026-09-14 02:21:44', 'Testing and final adjustment', 3.3);
INSERT INTO request_cost (request_id, cost_type, amount, remarks, recorded_at) VALUES (11, 'Other', 150, 'External charge', '2026-09-14 02:21:44');
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-14 04:46:09' WHERE request_id=11;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-14 16:01:29', closure_remarks='Work completed and verified by the requester', updated_at='2026-09-14 16:01:29' WHERE request_id=11;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (11, 4, 'Needed a second visit', '2026-09-16 04:14:24');

-- MR-2026-0012 [Civil] target state: Resolved
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0012', 6, 12, 18, 6, 3, 'Window latch broken and glass loose', 'Open', '2026-09-14 09:46:33', '2026-09-14 09:46:33');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (12, 8, '2026-09-15 12:20:04');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=12 ORDER BY assignment_id DESC LIMIT 1), '2026-09-15 22:33:20', 'Cleaned the area after repair', 0.9);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (12, 15, 2, 410, '2026-09-15 22:53:20');
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-16 00:45:07' WHERE request_id=12;

-- MR-2026-0013 [HVAC] target state: Resolved
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0013', 11, 4, 8, 4, 2, 'Split AC not cooling the room', 'Open', '2026-09-14 14:16:35', '2026-09-14 14:16:35');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (13, 6, '2026-09-15 15:18:39');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=13 ORDER BY assignment_id DESC LIMIT 1), '2026-09-15 22:11:28', 'Cleaned the area after repair', 0.5);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-16 03:59:01' WHERE request_id=13;

-- MR-2026-0014 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0014', 11, 7, 12, 2, 3, 'Blocked drain causing water stagnation', 'Open', '2026-09-15 13:07:46', '2026-09-15 13:07:46');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (14, 4, '2026-09-17 09:02:48');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=14 ORDER BY assignment_id DESC LIMIT 1), '2026-09-18 04:32:24', 'Replaced the defective component', 2.5);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (14, 6, 3, 310, '2026-09-18 04:52:24');
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-18 10:04:13' WHERE request_id=14;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-18 23:14:39', closure_remarks='Issue fixed; area cleaned and handed over', updated_at='2026-09-18 23:14:39' WHERE request_id=14;

-- MR-2026-0015 [Plumbing] target state: In Progress
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0015', 9, 11, NULL, 2, 4, 'Blocked drain causing water stagnation', 'Open', '2026-09-16 04:02:21', '2026-09-16 04:02:21');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (15, 3, '2026-09-19 08:12:53');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=15 ORDER BY assignment_id DESC LIMIT 1), '2026-09-19 13:49:44', 'Testing and final adjustment', 3.2);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (15, 7, 1, 540, '2026-09-19 14:09:44');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (15, 5, 15, 85, '2026-09-19 14:09:44');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=15 ORDER BY assignment_id DESC LIMIT 1), '2026-09-20 06:39:46', 'Cleaned the area after repair', 3.0);

-- MR-2026-0016 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0016', 2, 19, 26, 2, 3, 'Flush tank not filling properly', 'Open', '2026-09-16 12:35:56', '2026-09-16 12:35:56');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (16, 3, '2026-09-19 20:52:10');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=16 ORDER BY assignment_id DESC LIMIT 1), '2026-09-20 08:56:15', 'Testing and final adjustment', 3.0);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-20 14:42:55' WHERE request_id=16;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-21 03:22:18', closure_remarks='Completed as per request; no further action needed', updated_at='2026-09-21 03:22:18' WHERE request_id=16;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (16, 5, 'Needed a second visit', '2026-09-21 08:27:48');

-- MR-2026-0017 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0017', 12, 19, 26, 2, 2, 'Water leakage from the washbasin tap', 'Open', '2026-09-17 06:47:25', '2026-09-17 06:47:25');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (17, 3, '2026-09-18 10:16:47');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=17 ORDER BY assignment_id DESC LIMIT 1), '2026-09-19 05:49:00', 'Inspected the fault and isolated the problem', 1.1);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (17, 7, 2, 540, '2026-09-19 06:09:00');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (17, 8, 2, 25, '2026-09-19 06:09:00');
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-19 10:03:20' WHERE request_id=17;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-20 14:21:13', closure_remarks='Issue fixed; area cleaned and handed over', updated_at='2026-09-20 14:21:13' WHERE request_id=17;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (17, 5, 'Needed a second visit', '2026-09-20 22:01:05');

-- MR-2026-0018 [Civil] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0018', 1, 12, 18, 6, 2, 'Window latch broken and glass loose', 'Open', '2026-09-17 21:24:27', '2026-09-17 21:24:27');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (18, 8, '2026-09-18 17:41:35');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=18 ORDER BY assignment_id DESC LIMIT 1), '2026-09-19 02:56:57', 'Replaced the defective component', 1.1);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-19 05:11:23' WHERE request_id=18;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-19 10:09:55', closure_remarks='Issue fixed; area cleaned and handed over', updated_at='2026-09-19 10:09:55' WHERE request_id=18;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (18, 5, 'Excellent technician behaviour', '2026-09-19 14:01:03');

-- MR-2026-0019 [Furniture] target state: Open
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0019', 10, 2, 4, 3, 2, 'Cot frame loose and unstable', 'Open', '2026-09-19 01:56:13', '2026-09-19 01:56:13');

-- MR-2026-0020 [Electrical] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0020', 9, 16, 23, 1, 2, 'Corridor light fused and needs replacement', 'Open', '2026-09-19 13:56:15', '2026-09-19 13:56:15');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (20, 2, '2026-09-20 23:16:15');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=20 ORDER BY assignment_id DESC LIMIT 1), '2026-09-21 15:04:36', 'Testing and final adjustment', 1.2);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (20, 4, 2, 220, '2026-09-21 15:24:36');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=20 ORDER BY assignment_id DESC LIMIT 1), '2026-09-22 01:25:51', 'Testing and final adjustment', 2.2);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-22 06:03:00' WHERE request_id=20;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-23 08:03:11', closure_remarks='Repaired and tested in presence of the user', updated_at='2026-09-23 08:03:11' WHERE request_id=20;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (20, 3, 'Problem fixed on the first visit', '2026-09-23 17:38:23');

-- MR-2026-0021 [HVAC] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0021', 6, 17, 24, 4, 2, 'AC water dripping inside the room', 'Open', '2026-09-19 22:05:39', '2026-09-19 22:05:39');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (21, 6, '2026-09-21 01:46:06');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=21 ORDER BY assignment_id DESC LIMIT 1), '2026-09-21 07:14:22', 'Replaced the defective component', 2.4);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (21, 11, 2, 650, '2026-09-21 07:34:22');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (21, 12, 3, 420, '2026-09-21 07:34:22');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=21 ORDER BY assignment_id DESC LIMIT 1), '2026-09-21 15:52:47', 'Inspected the fault and isolated the problem', 0.9);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-21 19:45:06' WHERE request_id=21;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-22 15:28:51', closure_remarks='Repaired and tested in presence of the user', updated_at='2026-09-22 15:28:51' WHERE request_id=21;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (21, 5, 'Excellent technician behaviour', '2026-09-23 08:27:28');

-- MR-2026-0022 [Electrical] target state: In Progress
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0022', 11, 16, NULL, 1, 4, 'Tube lights flickering in the room', 'Open', '2026-09-20 05:45:22', '2026-09-20 05:45:22');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (22, 1, '2026-09-23 20:30:53');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=22 ORDER BY assignment_id DESC LIMIT 1), '2026-09-24 04:03:17', 'Replaced the defective component', 2.6);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (22, 4, 1, 220, '2026-09-24 04:23:17');

-- MR-2026-0023 [Civil] target state: Assigned
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0023', 7, 16, NULL, 6, 4, 'Crack on wall near the entrance', 'Open', '2026-09-20 14:57:33', '2026-09-20 14:57:33');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (23, 8, '2026-09-23 15:50:10');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (23, 14, 2, 950, '2026-09-23 17:50:10');

-- MR-2026-0024 [Furniture] target state: Open
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0024', 1, 15, NULL, 3, 3, 'Chair seat damaged and unsafe to use', 'Open', '2026-09-20 17:58:33', '2026-09-20 17:58:33');

-- MR-2026-0025 [Electrical] target state: Open
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0025', 9, 13, 20, 1, 3, 'Ceiling fan not working and making noise', 'Open', '2026-09-21 03:25:06', '2026-09-21 03:25:06');

-- MR-2026-0026 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0026', 6, 15, NULL, 2, 2, 'Flush tank not filling properly', 'Open', '2026-09-21 04:04:22', '2026-09-21 04:04:22');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (26, 3, '2026-09-22 06:31:54');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=26 ORDER BY assignment_id DESC LIMIT 1), '2026-09-23 01:29:42', 'Replaced the defective component', 0.6);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (26, 5, 5, 85, '2026-09-23 01:49:42');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=26 ORDER BY assignment_id DESC LIMIT 1), '2026-09-23 21:17:52', 'Testing and final adjustment', 3.2);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-23 23:53:13' WHERE request_id=26;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-24 15:19:06', closure_remarks='Repaired and tested in presence of the user', updated_at='2026-09-24 15:19:06' WHERE request_id=26;

-- MR-2026-0027 [Furniture] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0027', 1, 5, 9, 3, 1, 'Chair seat damaged and unsafe to use', 'Open', '2026-09-21 17:05:10', '2026-09-21 17:05:10');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (27, 5, '2026-09-21 19:03:25');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=27 ORDER BY assignment_id DESC LIMIT 1), '2026-09-22 12:43:36', 'Testing and final adjustment', 2.7);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (27, 10, 1, 60, '2026-09-22 13:03:36');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (27, 9, 1, 1450, '2026-09-22 13:03:36');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=27 ORDER BY assignment_id DESC LIMIT 1), '2026-09-23 08:24:15', 'Testing and final adjustment', 2.3);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-23 12:42:25' WHERE request_id=27;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-24 00:47:21', closure_remarks='Work completed and verified by the requester', updated_at='2026-09-24 00:47:21' WHERE request_id=27;

-- MR-2026-0028 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0028', 5, 17, NULL, 2, 3, 'Low water pressure in the shower', 'Open', '2026-09-23 04:46:17', '2026-09-23 04:46:17');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (28, 3, '2026-09-26 04:51:36');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=28 ORDER BY assignment_id DESC LIMIT 1), '2026-09-26 22:24:12', 'Replaced the defective component', 0.9);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (28, 6, 3, 310, '2026-09-26 22:44:12');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=28 ORDER BY assignment_id DESC LIMIT 1), '2026-09-27 14:51:43', 'Cleaned the area after repair', 1.3);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=28 ORDER BY assignment_id DESC LIMIT 1), '2026-09-27 20:11:09', 'Testing and final adjustment', 2.5);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-28 00:26:25' WHERE request_id=28;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-28 17:21:22', closure_remarks='Completed as per request; no further action needed', updated_at='2026-09-28 17:21:22' WHERE request_id=28;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (28, 4, 'Excellent technician behaviour', '2026-09-30 08:33:59');

-- MR-2026-0029 [Plumbing] target state: Resolved
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0029', 3, 19, NULL, 2, 1, 'Water leakage from the washbasin tap', 'Open', '2026-09-23 07:05:41', '2026-09-23 07:05:41');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (29, 4, '2026-09-23 09:12:32');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=29 ORDER BY assignment_id DESC LIMIT 1), '2026-09-23 14:34:30', 'Testing and final adjustment', 3.4);
INSERT INTO request_cost (request_id, cost_type, amount, remarks, recorded_at) VALUES (29, 'Transport', 300, 'External charge', '2026-09-23 14:34:30');
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-23 19:02:24' WHERE request_id=29;

-- MR-2026-0030 [Plumbing] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0030', 11, 19, 26, 2, 3, 'Water leakage from the washbasin tap', 'Open', '2026-09-24 04:57:57', '2026-09-24 04:57:57');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (30, 4, '2026-09-25 20:59:20');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=30 ORDER BY assignment_id DESC LIMIT 1), '2026-09-26 07:54:17', 'Replaced the defective component', 2.7);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-09-26 09:37:58' WHERE request_id=30;
UPDATE maintenance_request SET status='Closed', closed_at='2026-09-27 01:51:49', closure_remarks='Repaired and tested in presence of the user', updated_at='2026-09-27 01:51:49' WHERE request_id=30;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (30, 3, 'Needed a second visit', '2026-09-28 11:46:24');

-- MR-2026-0031 [Furniture] target state: Cancelled
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0031', 6, 6, NULL, 3, 3, 'Broken bench legs in the classroom', 'Open', '2026-09-25 17:19:27', '2026-09-25 17:19:27');
UPDATE maintenance_request SET status='Cancelled', updated_at='2026-09-25 23:19:27' WHERE request_id=31;

-- MR-2026-0032 [IT/AV] target state: Assigned
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0032', 11, 3, 6, 5, 2, 'Auditorium microphone has no sound', 'Open', '2026-09-30 05:34:47', '2026-09-30 05:34:47');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (32, 7, '2026-09-30 16:04:18');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (32, 13, 3, 380, '2026-09-30 18:04:18');

-- MR-2026-0033 [HVAC] target state: On Hold
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0033', 12, 9, 14, 4, 3, 'AC water dripping inside the room', 'Open', '2026-10-01 12:14:49', '2026-10-01 12:14:49');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (33, 6, '2026-10-05 17:56:27');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=33 ORDER BY assignment_id DESC LIMIT 1), '2026-10-06 02:57:28', 'Replaced the defective component', 2.5);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (33, 11, 1, 650, '2026-10-06 03:17:28');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (33, 12, 1, 420, '2026-10-06 03:17:28');
INSERT INTO request_cost (request_id, cost_type, amount, remarks, recorded_at) VALUES (33, 'Transport', 800, 'External charge', '2026-10-06 02:57:28');
UPDATE maintenance_request SET status='On Hold', updated_at='2026-10-06 03:57:28' WHERE request_id=33;

-- MR-2026-0034 [Plumbing] target state: Assigned
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0034', 7, 7, 12, 2, 3, 'Blocked drain causing water stagnation', 'Open', '2026-10-01 16:47:25', '2026-10-01 16:47:25');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (34, 4, '2026-10-03 07:29:53');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (34, 8, 3, 25, '2026-10-03 09:29:53');

-- MR-2026-0035 [Furniture] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0035', 6, 5, 9, 3, 2, 'Cupboard door hinge broken', 'Open', '2026-10-05 19:22:23', '2026-10-05 19:22:23');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (35, 5, '2026-10-06 17:06:20');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=35 ORDER BY assignment_id DESC LIMIT 1), '2026-10-06 21:26:44', 'Inspected the fault and isolated the problem', 1.9);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (35, 10, 2, 60, '2026-10-06 21:46:44');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=35 ORDER BY assignment_id DESC LIMIT 1), '2026-10-07 14:16:36', 'Inspected the fault and isolated the problem', 1.4);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=35 ORDER BY assignment_id DESC LIMIT 1), '2026-10-08 03:18:37', 'Cleaned the area after repair', 0.7);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-10-08 06:14:29' WHERE request_id=35;
UPDATE maintenance_request SET status='Closed', closed_at='2026-10-09 02:18:52', closure_remarks='Completed as per request; no further action needed', updated_at='2026-10-09 02:18:52' WHERE request_id=35;

-- MR-2026-0036 [Civil] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0036', 8, 12, 18, 6, 4, 'Door lock jammed and key stuck', 'Open', '2026-10-06 08:19:32', '2026-10-06 08:19:32');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (36, 8, '2026-10-07 06:37:56');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=36 ORDER BY assignment_id DESC LIMIT 1), '2026-10-08 02:01:05', 'Replaced the defective component', 3.2);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (36, 14, 1, 950, '2026-10-08 02:21:05');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (36, 15, 1, 410, '2026-10-08 02:21:05');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=36 ORDER BY assignment_id DESC LIMIT 1), '2026-10-08 10:14:16', 'Testing and final adjustment', 1.9);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=36 ORDER BY assignment_id DESC LIMIT 1), '2026-10-09 01:25:34', 'Replaced the defective component', 1.9);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-10-09 04:59:47' WHERE request_id=36;
UPDATE maintenance_request SET status='Closed', closed_at='2026-10-10 06:45:10', closure_remarks='Repaired and tested in presence of the user', updated_at='2026-10-10 06:45:10' WHERE request_id=36;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (36, 4, 'Fixed well but arrived late', '2026-10-11 00:51:18');

-- MR-2026-0037 [Electrical] target state: Open
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0037', 10, 10, 16, 1, 3, 'Ceiling fan not working and making noise', 'Open', '2026-10-06 22:38:28', '2026-10-06 22:38:28');

-- MR-2026-0038 [IT/AV] target state: Open
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0038', 4, 1, 2, 5, 3, 'Smart board touch not responding', 'Open', '2026-10-09 06:02:52', '2026-10-09 06:02:52');

-- MR-2026-0039 [Furniture] target state: In Progress
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0039', 4, 11, NULL, 3, 2, 'Cot frame loose and unstable', 'Open', '2026-10-10 06:18:42', '2026-10-10 06:18:42');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (39, 5, '2026-10-11 13:53:36');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=39 ORDER BY assignment_id DESC LIMIT 1), '2026-10-11 18:11:06', 'Cleaned the area after repair', 1.0);
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (39, 9, 2, 1450, '2026-10-11 18:31:06');
INSERT INTO request_material (request_id, material_id, quantity, unit_cost_used, used_at) VALUES (39, 10, 1, 60, '2026-10-11 18:31:06');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=39 ORDER BY assignment_id DESC LIMIT 1), '2026-10-12 10:55:01', 'Cleaned the area after repair', 2.9);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=39 ORDER BY assignment_id DESC LIMIT 1), '2026-10-12 20:43:57', 'Replaced the defective component', 0.5);
INSERT INTO request_cost (request_id, cost_type, amount, remarks, recorded_at) VALUES (39, 'Transport', 1200, 'External charge', '2026-10-12 20:43:57');

-- MR-2026-0040 [Furniture] target state: Closed
INSERT INTO maintenance_request (request_no, user_id, room_id, asset_id, category_id, priority_id, description, status, created_at, updated_at) VALUES ('MR-2026-0040', 6, 5, 9, 3, 4, 'Broken bench legs in the classroom', 'Open', '2026-10-07 08:30:00', '2026-10-07 08:30:00');
INSERT INTO assignment (request_id, tech_id, assigned_at) VALUES (40, 5, '2026-10-09 13:54:19');
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=40 ORDER BY assignment_id DESC LIMIT 1), '2026-10-10 04:14:41', 'Cleaned the area after repair', 1.6);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=40 ORDER BY assignment_id DESC LIMIT 1), '2026-10-10 21:32:23', 'Inspected the fault and isolated the problem', 2.0);
INSERT INTO work_log (assignment_id, log_time, work_done, hours_spent) VALUES ((SELECT assignment_id FROM assignment WHERE request_id=40 ORDER BY assignment_id DESC LIMIT 1), '2026-10-11 16:48:30', 'Replaced the defective component', 3.2);
UPDATE maintenance_request SET status='Resolved', updated_at='2026-10-11 22:39:48' WHERE request_id=40;
UPDATE maintenance_request SET status='Closed', closed_at='2026-10-12 01:58:47', closure_remarks='Work completed and verified by the requester', updated_at='2026-10-12 01:58:47' WHERE request_id=40;
INSERT INTO feedback (request_id, rating, comments, submitted_at) VALUES (40, 2, 'Fixed well but arrived late', '2026-10-12 03:15:53');
