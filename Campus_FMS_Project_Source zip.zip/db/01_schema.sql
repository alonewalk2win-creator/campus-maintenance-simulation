-- =====================================================================
--  CAMPUS FACILITY MAINTENANCE REQUEST MANAGEMENT SYSTEM
--  File : 01_schema.sql  (DDL, indexes, triggers, views)
--  DBMS : SQLite 3.45 (SQL is kept portable to MySQL / PostgreSQL;
--         trigger syntax and AUTOINCREMENT are SQLite specific)
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- 1. MASTER / REFERENCE TABLES
-- ---------------------------------------------------------------------
CREATE TABLE building (
    building_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    building_code  TEXT    NOT NULL UNIQUE,
    building_name  TEXT    NOT NULL UNIQUE,
    floors         INTEGER NOT NULL DEFAULT 1 CHECK (floors > 0)
);

CREATE TABLE room (
    room_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    building_id  INTEGER NOT NULL REFERENCES building(building_id)
                         ON UPDATE CASCADE ON DELETE RESTRICT,
    room_no      TEXT    NOT NULL,
    room_type    TEXT    NOT NULL DEFAULT 'Classroom'
                         CHECK (room_type IN ('Classroom','Laboratory','Office',
                                              'Hostel Room','Washroom','Corridor','Auditorium')),
    UNIQUE (building_id, room_no)
);

CREATE TABLE asset (
    asset_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id     INTEGER NOT NULL REFERENCES room(room_id)
                        ON UPDATE CASCADE ON DELETE RESTRICT,
    asset_tag   TEXT    NOT NULL UNIQUE,
    asset_name  TEXT    NOT NULL,
    asset_type  TEXT    NOT NULL
                        CHECK (asset_type IN ('Electrical','Plumbing','Furniture','HVAC','IT/AV','Civil'))
);

CREATE TABLE app_user (
    user_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name  TEXT NOT NULL,
    email      TEXT NOT NULL UNIQUE CHECK (email LIKE '%_@_%._%'),
    phone      TEXT CHECK (phone IS NULL OR (length(phone) BETWEEN 10 AND 15)),
    role       TEXT NOT NULL DEFAULT 'Student'
                    CHECK (role IN ('Student','Faculty','Staff','Facility Admin'))
);

CREATE TABLE category (
    category_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name  TEXT NOT NULL UNIQUE
);

CREATE TABLE priority (
    priority_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    priority_name  TEXT    NOT NULL UNIQUE,
    rank_no        INTEGER NOT NULL UNIQUE CHECK (rank_no BETWEEN 1 AND 9),
    sla_hours      INTEGER NOT NULL CHECK (sla_hours > 0)
);

CREATE TABLE technician (
    tech_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tech_name       TEXT    NOT NULL,
    category_id     INTEGER NOT NULL REFERENCES category(category_id)
                            ON UPDATE CASCADE ON DELETE RESTRICT,
    phone           TEXT,
    hourly_rate     REAL    NOT NULL DEFAULT 250 CHECK (hourly_rate >= 0),
    max_active_jobs INTEGER NOT NULL DEFAULT 4 CHECK (max_active_jobs > 0),
    is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE material (
    material_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    material_name  TEXT    NOT NULL UNIQUE,
    unit           TEXT    NOT NULL DEFAULT 'pcs',
    unit_cost      REAL    NOT NULL CHECK (unit_cost >= 0),
    stock_qty      REAL    NOT NULL DEFAULT 0 CHECK (stock_qty >= 0)
);

-- Status workflow is data, not code: the allowed transitions live in a table.
CREATE TABLE status_transition (
    from_status  TEXT NOT NULL,
    to_status    TEXT NOT NULL,
    PRIMARY KEY (from_status, to_status),
    CHECK (from_status <> to_status)
);

-- ---------------------------------------------------------------------
-- 2. TRANSACTION TABLES
-- ---------------------------------------------------------------------
CREATE TABLE maintenance_request (
    request_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    request_no       TEXT    NOT NULL UNIQUE,
    user_id          INTEGER NOT NULL REFERENCES app_user(user_id)
                             ON UPDATE CASCADE ON DELETE RESTRICT,
    room_id          INTEGER NOT NULL REFERENCES room(room_id)
                             ON UPDATE CASCADE ON DELETE RESTRICT,
    asset_id         INTEGER REFERENCES asset(asset_id)
                             ON UPDATE CASCADE ON DELETE SET NULL,
    category_id      INTEGER NOT NULL REFERENCES category(category_id)
                             ON UPDATE CASCADE ON DELETE RESTRICT,
    priority_id      INTEGER NOT NULL REFERENCES priority(priority_id)
                             ON UPDATE CASCADE ON DELETE RESTRICT,
    description      TEXT    NOT NULL CHECK (length(trim(description)) >= 10),
    status           TEXT    NOT NULL DEFAULT 'Open'
                             CHECK (status IN ('Open','Assigned','In Progress',
                                               'On Hold','Resolved','Closed','Cancelled')),
    created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    closed_at        TEXT,
    closure_remarks  TEXT,
    -- Business rule: closure details are mandatory for a Closed request
    CHECK (status <> 'Closed'
           OR (closed_at IS NOT NULL AND closure_remarks IS NOT NULL
               AND length(trim(closure_remarks)) >= 5)),
    CHECK (closed_at IS NULL OR closed_at >= created_at)
);

CREATE TABLE assignment (
    assignment_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id     INTEGER NOT NULL REFERENCES maintenance_request(request_id)
                           ON UPDATE CASCADE ON DELETE CASCADE,
    tech_id        INTEGER NOT NULL REFERENCES technician(tech_id)
                           ON UPDATE CASCADE ON DELETE RESTRICT,
    assigned_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    is_active      INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE work_log (
    log_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id  INTEGER NOT NULL REFERENCES assignment(assignment_id)
                           ON UPDATE CASCADE ON DELETE CASCADE,
    log_time       TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    work_done      TEXT    NOT NULL CHECK (length(trim(work_done)) >= 5),
    hours_spent    REAL    NOT NULL CHECK (hours_spent >= 0 AND hours_spent <= 24)
);

CREATE TABLE request_material (
    rm_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id     INTEGER NOT NULL REFERENCES maintenance_request(request_id)
                           ON UPDATE CASCADE ON DELETE CASCADE,
    material_id    INTEGER NOT NULL REFERENCES material(material_id)
                           ON UPDATE CASCADE ON DELETE RESTRICT,
    quantity       REAL    NOT NULL CHECK (quantity > 0),
    unit_cost_used REAL    NOT NULL CHECK (unit_cost_used >= 0),
    used_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Additional (non-material) costs: contractor charges, transport, disposal, etc.
CREATE TABLE request_cost (
    cost_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id   INTEGER NOT NULL REFERENCES maintenance_request(request_id)
                         ON UPDATE CASCADE ON DELETE CASCADE,
    cost_type    TEXT    NOT NULL CHECK (cost_type IN ('Contractor','Transport','Disposal','Other')),
    amount       REAL    NOT NULL CHECK (amount >= 0),
    remarks      TEXT,
    recorded_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE status_history (
    history_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id   INTEGER NOT NULL REFERENCES maintenance_request(request_id)
                         ON UPDATE CASCADE ON DELETE CASCADE,
    old_status   TEXT,
    new_status   TEXT    NOT NULL,
    changed_at   TEXT    NOT NULL
);

CREATE TABLE feedback (
    feedback_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id    INTEGER NOT NULL UNIQUE REFERENCES maintenance_request(request_id)
                          ON UPDATE CASCADE ON DELETE CASCADE,
    rating        INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comments      TEXT,
    submitted_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ---------------------------------------------------------------------
-- 3. INDEXES (frequently searched / joined attributes)
-- ---------------------------------------------------------------------
CREATE INDEX idx_request_status     ON maintenance_request(status);
CREATE INDEX idx_request_room       ON maintenance_request(room_id);
CREATE INDEX idx_request_cat_pri    ON maintenance_request(category_id, priority_id);
CREATE INDEX idx_request_created    ON maintenance_request(created_at);
CREATE INDEX idx_room_building      ON room(building_id);
CREATE INDEX idx_asset_room         ON asset(room_id);
CREATE INDEX idx_assign_tech_active ON assignment(tech_id, is_active);
CREATE INDEX idx_worklog_assign     ON work_log(assignment_id);
CREATE INDEX idx_reqmat_request     ON request_material(request_id);
CREATE INDEX idx_history_request    ON status_history(request_id);
-- Assignment control: at most ONE active assignment per request
CREATE UNIQUE INDEX uq_one_active_assignment ON assignment(request_id) WHERE is_active = 1;

-- ---------------------------------------------------------------------
-- 4. TRIGGERS (business-rule enforcement inside the database)
-- ---------------------------------------------------------------------
-- 4.1 Valid status transitions only
CREATE TRIGGER trg_status_transition_check
BEFORE UPDATE OF status ON maintenance_request
WHEN NEW.status <> OLD.status
 AND NOT EXISTS (SELECT 1 FROM status_transition
                 WHERE from_status = OLD.status AND to_status = NEW.status)
BEGIN
    SELECT RAISE(ABORT, 'Invalid status transition');
END;

-- 4.2 Automatic status history
CREATE TRIGGER trg_history_on_insert
AFTER INSERT ON maintenance_request
BEGIN
    INSERT INTO status_history(request_id, old_status, new_status, changed_at)
    VALUES (NEW.request_id, NULL, NEW.status, NEW.created_at);
END;

CREATE TRIGGER trg_history_on_update
AFTER UPDATE OF status ON maintenance_request
WHEN NEW.status <> OLD.status
BEGIN
    INSERT INTO status_history(request_id, old_status, new_status, changed_at)
    VALUES (NEW.request_id, OLD.status, NEW.status, NEW.updated_at);
END;

-- 4.3 Release technician when the request leaves the active workflow
CREATE TRIGGER trg_release_assignment
AFTER UPDATE OF status ON maintenance_request
WHEN NEW.status IN ('Open','Resolved','Closed','Cancelled')
BEGIN
    UPDATE assignment SET is_active = 0
     WHERE request_id = NEW.request_id AND is_active = 1;
END;

-- 4.4 Assignment control
CREATE TRIGGER trg_assignment_control
BEFORE INSERT ON assignment
WHEN NEW.is_active = 1
BEGIN
    SELECT RAISE(ABORT, 'Request is not open for assignment')
     WHERE (SELECT status FROM maintenance_request WHERE request_id = NEW.request_id)
           <> 'Open';
    SELECT RAISE(ABORT, 'Technician is inactive')
     WHERE (SELECT is_active FROM technician WHERE tech_id = NEW.tech_id) = 0;
    SELECT RAISE(ABORT, 'Technician has reached maximum active jobs')
     WHERE (SELECT COUNT(*) FROM assignment
             WHERE tech_id = NEW.tech_id AND is_active = 1)
        >= (SELECT max_active_jobs FROM technician WHERE tech_id = NEW.tech_id);
END;

CREATE TRIGGER trg_assignment_after
AFTER INSERT ON assignment
WHEN NEW.is_active = 1
BEGIN
    UPDATE maintenance_request
       SET status = 'Assigned', updated_at = NEW.assigned_at
     WHERE request_id = NEW.request_id AND status = 'Open';
END;

-- 4.5 Work can be logged only against an active assignment
CREATE TRIGGER trg_worklog_check
BEFORE INSERT ON work_log
BEGIN
    SELECT RAISE(ABORT, 'Work can be logged only against an active assignment')
     WHERE (SELECT is_active FROM assignment WHERE assignment_id = NEW.assignment_id) = 0;
END;

CREATE TRIGGER trg_worklog_after
AFTER INSERT ON work_log
BEGIN
    UPDATE maintenance_request
       SET status = 'In Progress', updated_at = NEW.log_time
     WHERE request_id = (SELECT request_id FROM assignment WHERE assignment_id = NEW.assignment_id)
       AND status = 'Assigned';
END;

-- 4.6 Materials: stock check and stock deduction
CREATE TRIGGER trg_material_stock_check
BEFORE INSERT ON request_material
BEGIN
    SELECT RAISE(ABORT, 'Insufficient material stock')
     WHERE NEW.quantity > (SELECT stock_qty FROM material WHERE material_id = NEW.material_id);
    SELECT RAISE(ABORT, 'Materials can be issued only to Assigned / In Progress / On Hold requests')
     WHERE (SELECT status FROM maintenance_request WHERE request_id = NEW.request_id)
           NOT IN ('Assigned','In Progress','On Hold');
END;

CREATE TRIGGER trg_material_stock_deduct
AFTER INSERT ON request_material
BEGIN
    UPDATE material SET stock_qty = stock_qty - NEW.quantity
     WHERE material_id = NEW.material_id;
END;

-- 4.7 Feedback only after closure
CREATE TRIGGER trg_feedback_check
BEFORE INSERT ON feedback
BEGIN
    SELECT RAISE(ABORT, 'Feedback is allowed only for Closed requests')
     WHERE (SELECT status FROM maintenance_request WHERE request_id = NEW.request_id) <> 'Closed';
END;

-- 4.8 Controlled removal: only untouched Open or Cancelled requests may be deleted
CREATE TRIGGER trg_request_delete_guard
BEFORE DELETE ON maintenance_request
WHEN OLD.status NOT IN ('Open','Cancelled')
BEGIN
    SELECT RAISE(ABORT, 'Only Open or Cancelled requests can be deleted');
END;

-- ---------------------------------------------------------------------
-- 5. VIEWS (reports)
-- ---------------------------------------------------------------------
-- 5.1 Pending requests (everything not Closed / Cancelled)
CREATE VIEW v_pending_requests AS
SELECT r.request_no, b.building_name, rm.room_no, c.category_name,
       p.priority_name, r.status, r.created_at,
       (SELECT t.tech_name FROM assignment a JOIN technician t ON t.tech_id = a.tech_id
         WHERE a.request_id = r.request_id AND a.is_active = 1) AS technician
  FROM maintenance_request r
  JOIN room rm     ON rm.room_id = r.room_id
  JOIN building b  ON b.building_id = rm.building_id
  JOIN category c  ON c.category_id = r.category_id
  JOIN priority p  ON p.priority_id = r.priority_id
 WHERE r.status NOT IN ('Closed','Cancelled')
 ORDER BY p.rank_no, r.created_at;

-- 5.2 Ageing of pending requests
CREATE VIEW v_request_ageing AS
SELECT r.request_no, c.category_name, p.priority_name, r.status,
       ROUND(julianday('now','localtime') - julianday(r.created_at), 1) AS age_days,
       CASE
         WHEN julianday('now','localtime') - julianday(r.created_at) <= 2  THEN '0-2 days'
         WHEN julianday('now','localtime') - julianday(r.created_at) <= 7  THEN '3-7 days'
         WHEN julianday('now','localtime') - julianday(r.created_at) <= 14 THEN '8-14 days'
         ELSE 'Over 14 days'
       END AS age_bucket
  FROM maintenance_request r
  JOIN category c ON c.category_id = r.category_id
  JOIN priority p ON p.priority_id = r.priority_id
 WHERE r.status NOT IN ('Closed','Cancelled');

-- 5.3 Response time (creation -> first assignment) and SLA check
CREATE VIEW v_response_time AS
SELECT r.request_no, p.priority_name, p.sla_hours,
       ROUND((julianday(MIN(a.assigned_at)) - julianday(r.created_at)) * 24, 1) AS response_hours,
       CASE WHEN (julianday(MIN(a.assigned_at)) - julianday(r.created_at)) * 24 <= p.sla_hours
            THEN 'Within SLA' ELSE 'SLA Breached' END AS sla_status
  FROM maintenance_request r
  JOIN assignment a ON a.request_id = r.request_id
  JOIN priority p   ON p.priority_id = r.priority_id
 GROUP BY r.request_id;

-- 5.4 Technician load
CREATE VIEW v_technician_load AS
SELECT t.tech_id, t.tech_name, c.category_name AS specialization, t.max_active_jobs,
       COUNT(CASE WHEN a.is_active = 1 THEN 1 END) AS active_jobs,
       COUNT(a.assignment_id)                       AS total_jobs_handled,
       ROUND(COALESCE((SELECT SUM(w.hours_spent) FROM work_log w
                        JOIN assignment a2 ON a2.assignment_id = w.assignment_id
                       WHERE a2.tech_id = t.tech_id), 0), 1) AS hours_logged
  FROM technician t
  JOIN category c ON c.category_id = t.category_id
  LEFT JOIN assignment a ON a.tech_id = t.tech_id
 GROUP BY t.tech_id;

-- 5.5 Cost per request (labour + materials + other)
CREATE VIEW v_request_cost AS
SELECT r.request_id, r.request_no, rm.building_id,
       COALESCE((SELECT SUM(w.hours_spent * t.hourly_rate)
                   FROM work_log w
                   JOIN assignment a ON a.assignment_id = w.assignment_id
                   JOIN technician t ON t.tech_id = a.tech_id
                  WHERE a.request_id = r.request_id), 0)                 AS labour_cost,
       COALESCE((SELECT SUM(m.quantity * m.unit_cost_used)
                   FROM request_material m WHERE m.request_id = r.request_id), 0) AS material_cost,
       COALESCE((SELECT SUM(x.amount)
                   FROM request_cost x WHERE x.request_id = r.request_id), 0)     AS other_cost
  FROM maintenance_request r
  JOIN room rm ON rm.room_id = r.room_id;

-- 5.6 Building-wise cost
CREATE VIEW v_building_cost AS
SELECT b.building_name,
       COUNT(vc.request_id)                       AS requests,
       ROUND(SUM(vc.labour_cost), 2)              AS labour,
       ROUND(SUM(vc.material_cost), 2)            AS material,
       ROUND(SUM(vc.other_cost), 2)               AS other,
       ROUND(SUM(vc.labour_cost + vc.material_cost + vc.other_cost), 2) AS total_cost
  FROM building b
  LEFT JOIN v_request_cost vc ON vc.building_id = b.building_id
 GROUP BY b.building_id
 ORDER BY total_cost DESC;

-- 5.7 Material use
CREATE VIEW v_material_use AS
SELECT mt.material_name, mt.unit,
       COALESCE(SUM(rm.quantity), 0)                       AS qty_used,
       ROUND(COALESCE(SUM(rm.quantity * rm.unit_cost_used), 0), 2) AS value_used,
       mt.stock_qty                                        AS stock_left
  FROM material mt
  LEFT JOIN request_material rm ON rm.material_id = mt.material_id
 GROUP BY mt.material_id
 ORDER BY value_used DESC;

-- 5.8 Feedback summary by category
CREATE VIEW v_feedback_summary AS
SELECT c.category_name,
       COUNT(f.feedback_id)        AS responses,
       ROUND(AVG(f.rating), 2)     AS avg_rating,
       MIN(f.rating)               AS lowest,
       MAX(f.rating)               AS highest
  FROM category c
  LEFT JOIN maintenance_request r ON r.category_id = c.category_id
  LEFT JOIN feedback f            ON f.request_id = r.request_id
 GROUP BY c.category_id;
