"""Builds campus_fms.db from the SQL scripts (replacement for the sqlite3 CLI)."""
import sqlite3, os, sys
here = os.path.dirname(os.path.abspath(__file__))
path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "campus_fms.db")
if os.path.exists(path):
    os.remove(path)
con = sqlite3.connect(path)
for f in ("01_schema.sql", "02_sample_data.sql"):
    con.executescript(open(os.path.join(here, f)).read())
con.commit()
print("built", path)
