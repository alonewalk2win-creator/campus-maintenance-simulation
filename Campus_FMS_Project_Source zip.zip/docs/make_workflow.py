import sqlite3, subprocess, os
here=os.path.dirname(os.path.abspath(__file__))
con=sqlite3.connect(os.path.join(here,"..","db","campus_fms.db"))
col={"Open":"#E36414","Assigned":"#2F6DB5","In Progress":"#C9A227","On Hold":"#7B4BA6","Resolved":"#2B8A5A","Closed":"#5C6B77","Cancelled":"#B03A2E"}
d=['digraph W {','rankdir=LR; dpi=170; pad=0.15; nodesep=0.5; ranksep=0.7; node [shape=box, style="rounded,filled", fontname="Helvetica", fontsize=12, fontcolor=white, margin="0.18,0.1"]; edge [color="#4A5A66", fontname="Helvetica", fontsize=9];']
for s,c in col.items(): d.append(f'"{s}" [fillcolor="{c}"];')
for a,b in con.execute("select from_status,to_status from status_transition"): d.append(f'"{a}" -> "{b}";')
d.append('}')
open(os.path.join(here,"workflow.dot"),"w").write("\n".join(d))
subprocess.run(["dot","-Tpng",os.path.join(here,"workflow.dot"),"-o",os.path.join(here,"workflow.png")],check=True)
from PIL import Image; print(Image.open(os.path.join(here,"workflow.png")).size)
