"""Draws the ER diagram (crow's-foot notation) from the live SQLite schema so it can never drift from the DDL."""
import sqlite3, subprocess, os
DB = os.path.join(os.path.dirname(__file__), "..", "db", "campus_fms.db")
con = sqlite3.connect(DB)
SHOW = {  # table -> (title, columns to display)
 "building": "Building", "room": "Room", "asset": "Asset", "app_user": "User", "category": "Category",
 "priority": "Priority", "technician": "Technician", "maintenance_request": "Maintenance Request",
 "assignment": "Assignment", "work_log": "Work Log", "request_material": "Request Material",
 "material": "Material", "request_cost": "Request Cost", "status_history": "Status History", "feedback": "Feedback",
 "status_transition": "Status Transition"}
COLOR = {"maintenance_request": "#0F4C5C", "assignment": "#16697A", "work_log": "#16697A", "request_material": "#16697A",
         "request_cost": "#16697A", "status_history": "#16697A", "feedback": "#16697A"}
def node(t):
    cols = con.execute(f"PRAGMA table_info({t})").fetchall()
    fks = {r[3] for r in con.execute(f"PRAGMA foreign_key_list({t})")}
    head = COLOR.get(t, "#5C6B77")
    rows = [f'<TR><TD BGCOLOR="{head}" COLSPAN="2"><FONT COLOR="white" POINT-SIZE="13"><B>{SHOW[t]}</B></FONT></TD></TR>']
    keep = []
    for cid, name, typ, nn, dflt, pk in cols:
        important = pk or name in fks or name in ("request_no", "status", "description", "created_at", "closed_at", "rating",
              "building_name", "room_no", "asset_name", "full_name", "category_name", "priority_name", "tech_name", "material_name",
              "quantity", "amount", "hours_spent", "max_active_jobs", "is_active", "closure_remarks", "sla_hours", "unit_cost", "stock_qty",
              "from_status", "to_status", "assigned_at", "new_status", "hourly_rate", "cost_type", "building_code", "asset_tag", "role", "email", "room_type", "asset_type", "unit_cost_used","work_done","log_time","comments")
        if important: keep.append((name, pk, name in fks))
    for name, pk, fk in keep[:11]:
        tag = "PK" if pk else ("FK" if fk else "")
        label = f"<B>{name}</B>" if pk else (f"<I>{name}</I>" if fk else name)
        rows.append(f'<TR><TD ALIGN="LEFT" WIDTH="150">{label}</TD><TD ALIGN="RIGHT">{('<FONT POINT-SIZE="9" COLOR="#888888">'+tag+'</FONT>') if tag else ' '}</TD></TR>')
    return f'{t} [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" COLOR="#8A98A3" BGCOLOR="white" STYLE="ROUNDED">{"".join(rows)}</TABLE>>];'
edges = [  # parent, child, label, child-side symbol
 ("building","room","has","crowodot"), ("room","asset","contains","crowodot"), ("room","maintenance_request","location of","crowodot"),
 ("asset","maintenance_request","concerns","crowodot"), ("app_user","maintenance_request","raises","crowodot"),
 ("category","maintenance_request","classifies","crowodot"), ("priority","maintenance_request","ranks","crowodot"),
 ("category","technician","specialises in","crowodot"), ("maintenance_request","assignment","is assigned via","crowodot"),
 ("technician","assignment","handles","crowodot"), ("assignment","work_log","records","crowodot"),
 ("maintenance_request","request_material","consumes","crowodot"), ("material","request_material","issued in","crowodot"),
 ("maintenance_request","request_cost","incurs","crowodot"), ("maintenance_request","status_history","tracked by","crowodot"),
 ("maintenance_request","feedback","receives","teeodot"),
]
dot = ['digraph ERD {','graph [rankdir=TB, nodesep=0.45, ranksep=0.75, fontname="Helvetica", pad=0.2, dpi=170, splines=true];',
       'node [shape=plain, fontname="Helvetica", fontsize=10];','edge [fontname="Helvetica", fontsize=9, color="#4A5A66", fontcolor="#16697A", dir=both, arrowtail=tee, penwidth=1.1];']
dot += [node(t) for t in SHOW]
for p, c, lab, sym in edges:
    dot.append(f'{p} -> {c} [label="{lab}", arrowhead={sym}];')
dot.append('status_transition -> maintenance_request [label="validates status", style=dashed, arrowtail=none, arrowhead=vee, constraint=false];')
dot.append('}')
open(os.path.join(os.path.dirname(__file__), "erd.dot"), "w").write("\n".join(dot))
subprocess.run(["dot", "-Tpng", os.path.join(os.path.dirname(__file__), "erd.dot"), "-o", os.path.join(os.path.dirname(__file__), "erd.png")], check=True)
from PIL import Image
im = Image.open(os.path.join(os.path.dirname(__file__), "erd.png")); print(im.size)
