"""Collects everything the report needs straight from the database / test results -> report_data.json"""
import sqlite3, json, os, sys, platform, re
here = os.path.dirname(os.path.abspath(__file__))
con = sqlite3.connect(os.path.join(here, "..", "db", "campus_fms.db")); con.row_factory = sqlite3.Row
import flask
D = {}
tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY rowid")]
D["tables"] = tables
D["n_tables"] = len(tables)
D["n_indexes"] = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_autoindex%'").fetchone()[0]
D["n_triggers"] = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0]
D["n_views"] = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='view'").fetchone()[0]
D["rows"] = {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in tables}
D["total_rows"] = sum(D["rows"].values())
D["versions"] = dict(python=platform.python_version(), sqlite=sqlite3.sqlite_version, flask=flask.__version__)

CHK = {("building","floors"):"CHECK > 0", ("room","room_type"):"CHECK in list", ("asset","asset_type"):"CHECK in list",
 ("app_user","email"):"CHECK format", ("app_user","phone"):"CHECK 10-15 chars", ("app_user","role"):"CHECK in list",
 ("priority","rank_no"):"CHECK 1-9", ("priority","sla_hours"):"CHECK > 0", ("technician","hourly_rate"):"CHECK >= 0",
 ("technician","max_active_jobs"):"CHECK > 0", ("technician","is_active"):"CHECK 0/1", ("material","unit_cost"):"CHECK >= 0",
 ("material","stock_qty"):"CHECK >= 0", ("maintenance_request","description"):"CHECK length >= 10",
 ("maintenance_request","status"):"CHECK in list", ("maintenance_request","closed_at"):"CHECK closure rule",
 ("maintenance_request","closure_remarks"):"CHECK closure rule", ("assignment","is_active"):"CHECK 0/1",
 ("work_log","work_done"):"CHECK length >= 5", ("work_log","hours_spent"):"CHECK 0-24", ("request_material","quantity"):"CHECK > 0",
 ("request_material","unit_cost_used"):"CHECK >= 0", ("request_cost","cost_type"):"CHECK in list", ("request_cost","amount"):"CHECK >= 0",
 ("feedback","rating"):"CHECK 1-5", ("status_transition","from_status"):"CHECK from <> to"}
DESC = {
 "building": {"building_id":"Surrogate key of the building","building_code":"Short unique code (e.g. ACB)","building_name":"Full unique building name","floors":"Number of floors"},
 "room": {"room_id":"Surrogate key of the room","building_id":"Building in which the room is located","room_no":"Room number, unique within a building","room_type":"Classroom, laboratory, office, washroom, etc."},
 "asset": {"asset_id":"Surrogate key of the asset","room_id":"Room where the asset is installed","asset_tag":"Unique inventory tag","asset_name":"Descriptive asset name","asset_type":"Trade type of the asset"},
 "app_user": {"user_id":"Surrogate key of the user","full_name":"Name of the requester / staff member","email":"Unique e-mail address","phone":"Contact number (optional)","role":"Student, faculty, staff or facility admin"},
 "category": {"category_id":"Surrogate key of the category","category_name":"Complaint category / trade (Electrical, Plumbing, ...)"},
 "priority": {"priority_id":"Surrogate key of the priority","priority_name":"Critical, High, Medium or Low","rank_no":"Sort order (1 = most urgent)","sla_hours":"Target hours to first assignment"},
 "technician": {"tech_id":"Surrogate key of the technician","tech_name":"Technician name","category_id":"Trade the technician specialises in","phone":"Contact number","hourly_rate":"Labour rate in Rs. per hour","max_active_jobs":"Maximum simultaneous active jobs","is_active":"1 = available for assignment, 0 = inactive"},
 "material": {"material_id":"Surrogate key of the material","material_name":"Unique material name","unit":"Unit of measure (pcs, m, kg ...)","unit_cost":"Current cost per unit (Rs.)","stock_qty":"Quantity available in store"},
 "status_transition": {"from_status":"Current status","to_status":"Status that may follow"},
 "maintenance_request": {"request_id":"Surrogate key of the request","request_no":"Unique business number (MR-YYYY-NNNN)","user_id":"Person who raised the request","room_id":"Room where the fault exists","asset_id":"Faulty asset (optional)","category_id":"Complaint category","priority_id":"Urgency of the request","description":"Problem description","status":"Current workflow status","created_at":"Date and time of logging","updated_at":"Time of last status change","closed_at":"Date and time of closure","closure_remarks":"Mandatory remarks when closed"},
 "assignment": {"assignment_id":"Surrogate key of the assignment","request_id":"Request being handled","tech_id":"Technician assigned","assigned_at":"Date and time of assignment","is_active":"1 while the technician holds the job"},
 "work_log": {"log_id":"Surrogate key of the log entry","assignment_id":"Assignment under which work was done","log_time":"Date and time of the entry","work_done":"Description of the work done","hours_spent":"Hours spent in this entry"},
 "request_material": {"rm_id":"Surrogate key of the material issue","request_id":"Request receiving the material","material_id":"Material issued","quantity":"Quantity issued","unit_cost_used":"Unit cost at the time of issue (historical value)","used_at":"Date and time of issue"},
 "request_cost": {"cost_id":"Surrogate key of the cost entry","request_id":"Request incurring the cost","cost_type":"Contractor, transport, disposal or other","amount":"Amount in Rs.","remarks":"Optional note","recorded_at":"Date and time recorded"},
 "status_history": {"history_id":"Surrogate key of the history row","request_id":"Request whose status changed","old_status":"Previous status (NULL for creation)","new_status":"New status","changed_at":"Date and time of change"},
 "feedback": {"feedback_id":"Surrogate key of the feedback","request_id":"Closed request being rated (one per request)","rating":"Satisfaction score from 1 to 5","comments":"Optional comments","submitted_at":"Date and time submitted"},
}
dd, notation = [], []
for t in tables:
    uniq = set()
    for idx in con.execute(f"PRAGMA index_list({t})"):
        if idx["origin"] == "u" and len(con.execute(f"PRAGMA index_info({idx['name']})").fetchall()) == 1:
            uniq.add(con.execute(f"PRAGMA index_info({idx['name']})").fetchone()["name"])
    fks = {r["from"]: r["table"] for r in con.execute(f"PRAGMA foreign_key_list({t})")}
    parts = []
    for c in con.execute(f"PRAGMA table_info({t})"):
        n = c["name"]; k = []
        if c["pk"]: k.append("PK")
        if n in fks: k.append(f"FK > {fks[n]}")
        if n in uniq: k.append("UNIQUE")
        if c["notnull"] and not c["pk"]: k.append("NOT NULL")
        if c["dflt_value"] is not None: k.append("DEFAULT")
        if (t, n) in CHK: k.append(CHK[(t, n)])
        dd.append(dict(table=t, attr=n, type=c["type"], key=", ".join(k) or "-", desc=DESC[t][n]))
        parts.append(f"{n} (PK)" if c["pk"] else (f"{n} (FK)" if n in fks else (f"{n} (UQ)" if n in uniq else n)))
    notation.append(f"{t}({', '.join(parts)})")
D["dictionary"], D["notation"] = dd, notation

def rows(sql, lim=None):
    r = [list(x) for x in con.execute(sql)]
    return r[:lim] if lim else r
D["sample_requests"] = rows("""SELECT request_no, building_code||' '||room_no, category_name, priority_name, status, substr(created_at,1,16)
  FROM maintenance_request r JOIN room USING(room_id) JOIN building USING(building_id) JOIN category USING(category_id) JOIN priority USING(priority_id)
  WHERE r.request_id IN (1,5,12,20,30,38) ORDER BY r.request_id""")
D["pending"] = rows("SELECT request_no, building_name, room_no, category_name, priority_name, status, COALESCE(technician,'-') FROM v_pending_requests", 8)
D["n_pending"] = con.execute("SELECT COUNT(*) FROM v_pending_requests").fetchone()[0]
D["status_counts"] = {r[0]: r[1] for r in con.execute("SELECT status, COUNT(*) FROM maintenance_request GROUP BY status")}
D["ageing"] = rows("SELECT age_bucket, COUNT(*), ROUND(AVG(age_days),1), MAX(age_days) FROM v_request_ageing GROUP BY age_bucket ORDER BY MIN(age_days)")
D["response"] = rows("SELECT request_no, priority_name, sla_hours, response_hours, sla_status FROM v_response_time ORDER BY response_hours DESC", 8)
D["sla"] = {r[0]: r[1] for r in con.execute("SELECT sla_status, COUNT(*) FROM v_response_time GROUP BY sla_status")}
D["avg_response"] = con.execute("SELECT ROUND(AVG(response_hours),1) FROM v_response_time").fetchone()[0]
D["load"] = rows("SELECT tech_name, specialization, active_jobs, max_active_jobs, total_jobs_handled, hours_logged FROM v_technician_load ORDER BY active_jobs DESC, tech_name")
D["cost"] = rows("SELECT building_name, requests, labour, material, other, total_cost FROM v_building_cost")
D["cost_total"] = con.execute("SELECT ROUND(SUM(total_cost),0) FROM v_building_cost").fetchone()[0]
D["material"] = rows("SELECT material_name, unit, qty_used, value_used, stock_left FROM v_material_use", 8)
D["feedback"] = rows("SELECT category_name, responses, avg_rating, lowest, highest FROM v_feedback_summary ORDER BY avg_rating DESC")
D["avg_rating"] = list(con.execute("SELECT ROUND(AVG(rating),2), COUNT(*) FROM feedback").fetchone())
D["tests"] = json.load(open(os.path.join(here, "test_results.json")))
json.dump(D, open(os.path.join(here, "report_data.json"), "w"), indent=1, default=str)
print({k: D[k] for k in ("n_tables","n_indexes","n_triggers","n_views","total_rows","versions","n_pending","avg_response","sla","cost_total","avg_rating")})
print(len(dd), "dictionary rows")
