"""Drives the real running application with a headless browser and saves screenshots for the report."""
import os, shutil, subprocess, sys, time, sqlite3, urllib.request
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SH = os.path.join(ROOT, "docs", "shots")
DB = "/tmp/demo_shots.db"
subprocess.run([sys.executable, os.path.join(ROOT, "db", "build_db.py"), DB], check=True, capture_output=True)
con = sqlite3.connect(DB)
# make one technician (HVAC, id 6) fully loaded so the capacity rule can be demonstrated
active6 = con.execute("SELECT COUNT(*) FROM assignment WHERE tech_id=6 AND is_active=1").fetchone()[0]
con.execute("UPDATE technician SET max_active_jobs=? WHERE tech_id=6", (max(active6, 1),)); con.commit()
env = dict(os.environ, CAMPUS_DB=DB)
srv = subprocess.Popen([sys.executable, os.path.join(ROOT, "app", "app.py")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(40):
    try: urllib.request.urlopen("http://127.0.0.1:5000/"); break
    except Exception: time.sleep(0.25)
B = "http://127.0.0.1:5000"
def one(sql): return con.execute(sql).fetchone()[0]
with sync_playwright() as p:
    br = p.chromium.launch(); pg = br.new_page(viewport={"width": 1280, "height": 900}, device_scale_factor=1.5)
    def shot(name, clip_h=None, full=False):
        pg.screenshot(path=f"{SH}/{name}.png", clip=None if full else {"x": 0, "y": 0, "width": 1280, "height": clip_h or 800})
    pg.goto(B + "/"); shot("dashboard", 640)
    # --- data entry
    pg.goto(B + "/requests/new")
    pg.select_option("select[name=user_id]", label="Sneha Reddy (Student)")
    pg.select_option("#b", label="Science and Lab Block"); pg.select_option("#r", label="S-L01")
    pg.select_option("#a", label="Fume Hood S-L01"); pg.select_option("select[name=category_id]", label="HVAC")
    pg.select_option("select[name=priority_id]", label="High (SLA 24 h)")
    pg.fill("textarea[name=description]", "Fume hood extraction is very weak and fumes remain in the laboratory")
    shot("new_request", 560)
    pg.click("button:has-text('Submit Request')"); pg.wait_for_load_state()
    shot("request_logged", 640)
    # --- search / filter
    pg.goto(B + "/requests?status=In+Progress&category=1"); shot("search", 460)
    pg.goto(B + "/requests?q=Water"); 
    # --- request detail (a request that has assignment, logs, materials)
    rid = one("SELECT r.request_id FROM maintenance_request r WHERE r.status='In Progress' AND EXISTS (SELECT 1 FROM request_material m WHERE m.request_id=r.request_id) LIMIT 1")
    pg.goto(f"{B}/requests/{rid}"); shot("request_detail", full=True)
    # --- capacity rule: assign a 2nd job to the loaded HVAC technician
    new_id = one("SELECT MAX(request_id) FROM maintenance_request")
    pg.goto(f"{B}/requests/{new_id}")
    pg.select_option("select[name=tech_id]", index=0)  # first option = same-category technician (HVAC, id 6)
    pg.click("form[action$='/assign'] button"); pg.wait_for_load_state(); shot("assign_refused", 330)
    # --- assign properly: choose a technician with spare capacity (any other) then show Assigned
    # closure rule
    rr = one("SELECT request_id FROM maintenance_request WHERE status='Resolved' LIMIT 1")
    pg.goto(f"{B}/requests/{rr}"); pg.click("button:has-text('Close request')"); pg.wait_for_load_state(); shot("close_refused", 420)
    pg.fill("textarea[name=closure_remarks]", "Repair verified with the requester and area cleaned")
    pg.click("button:has-text('Close request')"); pg.wait_for_load_state(); shot("closed_ok", 420)
    # --- reports
    pg.goto(B + "/reports/load"); shot("report_load", 600)
    pg.goto(B + "/reports/cost"); shot("report_cost", 520)
    pg.goto(B + "/reports/pending"); shot("report_pending", 900)
    pg.goto(B + "/reports/response"); shot("report_response", 900)
    br.close()
srv.terminate()
print(os.listdir(SH))
