"""Executable test suite. Each test runs on a freshly built database and records the OBSERVED outcome
(expected vs actual) in docs/test_results.json - the report's Table 15 is generated from that file."""
import json
import os
import re
import sqlite3
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "app"))
RESULTS = []


def fresh_db():
    path = tempfile.mktemp(suffix=".db")
    subprocess.run([sys.executable, os.path.join(ROOT, "db", "build_db.py"), path], check=True, capture_output=True)
    os.environ["CAMPUS_DB"] = path
    import importlib
    import app as A
    importlib.reload(A)
    A.app.config["TESTING"] = True
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return A, A.app.test_client(), con


def flash_of(client, resp_follow=True):
    with client.session_transaction() as s:
        return [m for _, m in s.get("_flashes", [])]


def one(con, sql, *a):
    r = con.execute(sql, a).fetchone()
    return r[0] if r else None


def record(tid, feature, action, expected, actual, ok):
    RESULTS.append(dict(id=tid, feature=feature, action=action, expected=expected, actual=actual,
                        status="Pass" if ok else "Fail"))
    print(f"{tid} {'PASS' if ok else 'FAIL'} - {feature}: {actual}")


def sql_error(con, sql, args=()):
    try:
        con.execute(sql, args)
        con.commit()
        return None
    except sqlite3.Error as e:
        con.rollback()
        return str(e)


# ---------------------------------------------------------------------------------------------
def t01_create():
    A, c, con = fresh_db()
    before = one(con, "SELECT COUNT(*) FROM maintenance_request")
    c.post("/requests/new", data=dict(user_id=1, room_id=1, asset_id=1, category_id=1, priority_id=2,
                                      description="Ceiling fan wobbling dangerously in Room A-101"))
    row = con.execute("SELECT request_no,status FROM maintenance_request ORDER BY request_id DESC LIMIT 1").fetchone()
    hist = one(con, "SELECT COUNT(*) FROM status_history WHERE request_id=?", before + 1)
    ok = one(con, "SELECT COUNT(*) FROM maintenance_request") == before + 1 and row["status"] == "Open" and hist == 1
    record("TC-01", "Log request (Create)", "Submit new request with valid data",
           "Row inserted, number auto-generated, status Open, history row created",
           f"{row['request_no']} created with status {row['status']}; {hist} history row", ok)


def t02_short_desc():
    A, c, con = fresh_db()
    before = one(con, "SELECT COUNT(*) FROM maintenance_request")
    r = c.post("/requests/new", data=dict(user_id=1, room_id=1, category_id=1, priority_id=2, description="fan"))
    m = re.search(r'<div class="flash err">(.*?)</div>', r.data.decode())      # form is re-displayed with the message
    msg = m.group(1) if m else ""
    ok = one(con, "SELECT COUNT(*) FROM maintenance_request") == before and "Description" in msg
    record("TC-02", "Input validation", "Submit request with 3-character description",
           "Rejected with validation message; no row inserted", f"Rejected: '{msg}'", ok)


def t03_dup_no():
    A, c, con = fresh_db()
    err = sql_error(con, """INSERT INTO maintenance_request(request_no,user_id,room_id,category_id,priority_id,description)
                            VALUES ('MR-2026-0001',1,1,1,1,'Duplicate request number test')""")
    ok = err is not None and "UNIQUE" in err
    record("TC-03", "Unique request number", "Insert a second request with number MR-2026-0001",
           "UNIQUE constraint violation", err or "Inserted (rule not enforced)", ok)


def t04_assign():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='Open' AND category_id=1 LIMIT 1") \
        or one(con, "SELECT request_id FROM maintenance_request WHERE status='Open' LIMIT 1")
    cat = one(con, "SELECT category_id FROM maintenance_request WHERE request_id=?", rid)
    tech = one(con, "SELECT tech_id FROM technician WHERE category_id=? ORDER BY tech_id LIMIT 1", cat)
    c.post(f"/requests/{rid}/assign", data=dict(tech_id=tech))
    st = one(con, "SELECT status FROM maintenance_request WHERE request_id=?", rid)
    act = one(con, "SELECT COUNT(*) FROM assignment WHERE request_id=? AND is_active=1", rid)
    record("TC-04", "Technician assignment", "Assign a technician to an Open request",
           "Active assignment created; request status becomes Assigned", f"Status {st}; active assignments = {act}",
           st == "Assigned" and act == 1)


def t05_capacity():
    A, c, con = fresh_db()
    tech = 6  # HVAC technician
    con.execute("UPDATE technician SET max_active_jobs=1 WHERE tech_id=?", (tech,))
    con.execute("UPDATE assignment SET is_active=0 WHERE tech_id=?", (tech,))
    con.commit()
    opens = [r[0] for r in con.execute("SELECT request_id FROM maintenance_request WHERE status='Open' LIMIT 2")]
    c.post(f"/requests/{opens[0]}/assign", data=dict(tech_id=tech))
    c.post(f"/requests/{opens[1]}/assign", data=dict(tech_id=tech))
    msg = flash_of(c)
    st2 = one(con, "SELECT status FROM maintenance_request WHERE request_id=?", opens[1])
    ok = st2 == "Open" and any("maximum number of active jobs" in m for m in msg)
    record("TC-05", "Assignment control (capacity)", "Assign a 2nd request to technician whose limit is 1 active job",
           "Refused with message; second request stays Open", f"{msg[-1] if msg else ''} (status {st2})", ok)


def t06_double_assign():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='Assigned' LIMIT 1")
    c.post(f"/requests/{rid}/assign", data=dict(tech_id=8))
    msg = flash_of(c)
    n = one(con, "SELECT COUNT(*) FROM assignment WHERE request_id=? AND is_active=1", rid)
    record("TC-06", "Assignment control (one active)", "Assign another technician to an already Assigned request",
           "Refused; still exactly one active assignment", f"{msg[-1] if msg else ''} (active assignments = {n})",
           n == 1 and any("only Open" in m for m in msg))


def t07_bad_transition():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='Open' LIMIT 1")
    err = sql_error(con, "UPDATE maintenance_request SET status='Resolved' WHERE request_id=?", (rid,))
    st = one(con, "SELECT status FROM maintenance_request WHERE request_id=?", rid)
    record("TC-07", "Valid status transitions", "Change status directly from Open to Resolved",
           "Rejected by trigger; status stays Open", f"{err}; status = {st}", err is not None and "Invalid status" in err and st == "Open")


def t08_close_no_remarks():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='Resolved' LIMIT 1")
    c.post(f"/requests/{rid}/close", data=dict(closure_remarks=""))
    msg = flash_of(c)
    st = one(con, "SELECT status FROM maintenance_request WHERE request_id=?", rid)
    record("TC-08", "Closure details required", "Close a Resolved request with empty closure remarks",
           "Rejected by CHECK constraint; status stays Resolved", f"{msg[-1] if msg else ''} (status {st})",
           st == "Resolved" and any("Closure details" in m for m in msg))


def t09_close_ok():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='Resolved' LIMIT 1")
    c.post(f"/requests/{rid}/close", data=dict(closure_remarks="Repair verified with the requester"))
    r = con.execute("SELECT status, closed_at FROM maintenance_request WHERE request_id=?", (rid,)).fetchone()
    record("TC-09", "Close request", "Close a Resolved request with closure remarks",
           "Status Closed with closed_at populated", f"Status {r['status']}; closed_at {r['closed_at']}",
           r["status"] == "Closed" and r["closed_at"] is not None)


def t10_negative_qty():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='In Progress' LIMIT 1")
    n0 = one(con, "SELECT COUNT(*) FROM request_material")
    c.post(f"/requests/{rid}/material", data=dict(material_id=1, quantity="-3"))
    msg = flash_of(c)
    ok = one(con, "SELECT COUNT(*) FROM request_material") == n0 and any("Quantity" in m for m in msg)
    record("TC-10", "Non-negative materials", "Issue material with quantity -3",
           "Rejected; no material row", f"{msg[-1] if msg else ''}", ok)


def t11_negative_cost_db():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='In Progress' LIMIT 1")
    err = sql_error(con, "INSERT INTO request_cost(request_id,cost_type,amount) VALUES (?,?,?)", (rid, "Other", -500))
    record("TC-11", "Non-negative costs (DB level)", "Insert additional cost of -500 directly through SQL",
           "CHECK constraint violation", err or "Inserted (rule not enforced)", err is not None and "CHECK" in err)


def t12_stock():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='In Progress' LIMIT 1")
    stock = one(con, "SELECT stock_qty FROM material WHERE material_id=9")
    n0 = one(con, "SELECT COUNT(*) FROM request_material")
    c.post(f"/requests/{rid}/material", data=dict(material_id=9, quantity=str(stock + 50)))
    msg = flash_of(c)
    ok = one(con, "SELECT COUNT(*) FROM request_material") == n0 and one(con, "SELECT stock_qty FROM material WHERE material_id=9") == stock
    record("TC-12", "Stock check / rollback", f"Issue {stock + 50:g} sheets when only {stock:g} are in stock",
           "Refused; stock and material rows unchanged", f"{msg[-1] if msg else ''}", ok and any("stock" in m for m in msg))


def t13_material_ok():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='In Progress' LIMIT 1")
    stock = one(con, "SELECT stock_qty FROM material WHERE material_id=1")
    cost0 = one(con, "SELECT material_cost FROM v_request_cost WHERE request_id=?", rid)
    c.post(f"/requests/{rid}/material", data=dict(material_id=1, quantity="2"))
    stock1 = one(con, "SELECT stock_qty FROM material WHERE material_id=1")
    cost1 = one(con, "SELECT material_cost FROM v_request_cost WHERE request_id=?", rid)
    record("TC-13", "Material entry (Update)", "Issue 2 LED tubes to an In Progress request",
           "Stock reduced by 2; request material cost rises by Rs. 360",
           f"Stock {stock:g} -> {stock1:g}; material cost {cost0:g} -> {cost1:g}", stock1 == stock - 2 and cost1 - cost0 == 360)


def t14_feedback():
    A, c, con = fresh_db()
    open_rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='In Progress' LIMIT 1")
    c.post(f"/requests/{open_rid}/feedback", data=dict(rating=4, comments="ok"))
    m1 = flash_of(c)[-1:]
    closed = one(con, """SELECT request_id FROM maintenance_request WHERE status='Closed'
                         AND request_id NOT IN (SELECT request_id FROM feedback) LIMIT 1""")
    c.post(f"/requests/{closed}/feedback", data=dict(rating=6, comments="x"))
    m2 = flash_of(c)[-1:]
    c.post(f"/requests/{closed}/feedback", data=dict(rating=4, comments="Good work"))
    stored = one(con, "SELECT rating FROM feedback WHERE request_id=?", closed)
    c.post(f"/requests/{closed}/feedback", data=dict(rating=5, comments="again"))
    m3 = flash_of(c)[-1:]
    ok = stored == 4 and any("only after" in m for m in m1) and any("between" in m for m in m2) and any("already" in m for m in m3)
    record("TC-14", "Feedback rules", "Feedback on open job; rating 6; valid rating 4; duplicate feedback",
           "Open job refused; 6 refused; 4 stored; duplicate refused",
           f"Open job: refused; rating 6: refused; stored rating = {stored}; duplicate: refused", ok)


def t15_delete():
    A, c, con = fresh_db()
    prog = one(con, "SELECT request_id FROM maintenance_request WHERE status='In Progress' LIMIT 1")
    c.post(f"/requests/{prog}/delete")
    still = one(con, "SELECT COUNT(*) FROM maintenance_request WHERE request_id=?", prog)
    msg = flash_of(c)[-1:]
    opn = one(con, "SELECT request_id FROM maintenance_request WHERE status='Open' LIMIT 1")
    c.post(f"/requests/{opn}/delete")
    gone = one(con, "SELECT COUNT(*) FROM maintenance_request WHERE request_id=?", opn)
    record("TC-15", "Controlled removal (Delete)", "Delete an In Progress request, then delete an Open request",
           "In Progress delete refused; Open delete succeeds",
           f"In Progress: {'refused' if still else 'deleted'}; Open: {'deleted' if not gone else 'refused'}",
           still == 1 and gone == 0 and any("only Open or Cancelled" in m for m in msg))


def t16_fk():
    A, c, con = fresh_db()
    c.post("/locations/building/1/delete")
    msg = flash_of(c)[-1:]
    n = one(con, "SELECT COUNT(*) FROM building WHERE building_id=1")
    record("TC-16", "Referential integrity", "Delete a building that still has rooms",
           "Refused by FOREIGN KEY (ON DELETE RESTRICT); building remains", f"{msg[0] if msg else ''}", n == 1 and bool(msg) and "referenced" in msg[0])


def t17_search():
    A, c, con = fresh_db()
    r = c.get("/requests?status=Open&category=1")
    html = r.data.decode()
    shown = len(re.findall(r'href="/requests/\d+"', html))
    exp = one(con, "SELECT COUNT(*) FROM maintenance_request WHERE status='Open' AND category_id=1")
    record("TC-17", "Search / filter (Read)", "Filter requests: status = Open and category = Electrical",
           f"Only matching requests listed ({exp})", f"{shown} request(s) listed", shown == exp)


def t18_reports():
    A, c, con = fresh_db()
    codes = {k: c.get(f"/reports/{k}").status_code for k in A.REPORTS}
    total_view = one(con, "SELECT ROUND(SUM(total_cost),2) FROM v_building_cost")
    total_raw = one(con, "SELECT ROUND(SUM(labour_cost+material_cost+other_cost),2) FROM v_request_cost")
    record("TC-18", "Reports", "Open all 8 report pages; compare building-wise cost total with request-wise total",
           "All pages load; both totals equal", f"Status codes {sorted(set(codes.values()))}; totals {total_view:g} vs {total_raw:g}",
           set(codes.values()) == {200} and total_view == total_raw)


def t19_cancel_release():
    A, c, con = fresh_db()
    rid = one(con, "SELECT request_id FROM maintenance_request WHERE status='Assigned' LIMIT 1")
    c.post(f"/requests/{rid}/status", data=dict(new_status="Cancelled"))
    st = one(con, "SELECT status FROM maintenance_request WHERE request_id=?", rid)
    act = one(con, "SELECT COUNT(*) FROM assignment WHERE request_id=? AND is_active=1", rid)
    record("TC-19", "Status update + release", "Cancel an Assigned request",
           "Status Cancelled; technician released (0 active assignments)", f"Status {st}; active assignments {act}",
           st == "Cancelled" and act == 0)


if __name__ == "__main__":
    for fn in [t01_create, t02_short_desc, t03_dup_no, t04_assign, t05_capacity, t06_double_assign, t07_bad_transition,
               t08_close_no_remarks, t09_close_ok, t10_negative_qty, t11_negative_cost_db, t12_stock, t13_material_ok,
               t14_feedback, t15_delete, t16_fk, t17_search, t18_reports, t19_cancel_release]:
        try:
            fn()
        except Exception as e:                      # a crashing test is recorded as a failure
            record(fn.__name__, fn.__name__, "-", "-", f"Exception: {e!r}", False)
    out = os.path.join(ROOT, "docs", "test_results.json")
    json.dump(RESULTS, open(out, "w"), indent=1)
    p = sum(r["status"] == "Pass" for r in RESULTS)
    print(f"\n{p}/{len(RESULTS)} passed -> {out}")
